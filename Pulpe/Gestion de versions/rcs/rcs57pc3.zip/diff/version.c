#include <config.h>
char const version_string[] = "GNU diffutils 2.7.1";
