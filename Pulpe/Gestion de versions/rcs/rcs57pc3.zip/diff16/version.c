/* Version number of GNU diff.  */
/*
   Modified for DOS and OS/2 on 1991/09/14 by Kai Uwe Rommel
	<rommel@ars.muc.de>.
*/

char *version_string = "1.15 (16-bit)";

#ifdef __TURBOC__
unsigned _stklen = 0x8000;
#endif
