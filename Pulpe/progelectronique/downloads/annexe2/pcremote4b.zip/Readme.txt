**************************
PC REMOTE CONTROL 4.0 BETA                                        February 2001
**************************

http://www.pcremotecontrol.com

Copyright (c) 1997-2001 by Moises Cambra, mcambra@pcremotecontrol.com
All rights reserved.


IMPORTANT NOTE
==============

This is a beta version, meaning that it is not complete and some functions may
not work well or differently as they should do in theory. It can also have
undetected bugs that could make your system unstable. In case of finding a
problem or malfunction, even a little bug, you are encouraged to report it to
the email above, including all the information that could help me to solve it as
soon as possible.

The help file is still undone, so by the moment you must experiment by yourself
and discover how things work. Yet, if there is something you don't understand or
know how to do, feel free to email me your question. That would be a guide to
know what points need more explanation or clarification.

The interface translation to other languages will be possible in this version as
well, but for the moment I want to concentrate in the program features and wait
till everything is well stablished to prepare the translation files.


WHAT IS NEW IN THIS VERSION
===========================

- Completely new rebuilt code, all known bugs have been removed.

- The actions are not linked to a unique remote command. Different remote
commands can trigger the same action, and a single remote command can trigger
different actions.

- Advanced action triggering based on sequential combinations of selectable
remote commands.

- It is possible to define different groups of actions depending on the
foreground application, so that the same triggering sequence acts accordingly to
the active window.

- New features added to already existing actions:

  * Individual delay time for every action
  * The destination window for the 'Tap key' and 'PostMessage' actions can be
    kept active.
  * Double click and absolute position movement in the 'Mouse move' action.
  * Possibility of entering in suspend mode before executing an external program
    and waiting till the application finishes to become active again. Useful
    when launching programs that need access to the serial port.
  * Customizable list of Windows messages for specific applications.

- New available actions:

  * Volume control through the Windows mixer.
  * Log off, reboot or shutdown
  * Minimize, maximize, restore or close active window.
  * On Screen Display of the current time, date or whatever desired text.

- Easier configuration file management with standard Open, Save and Save As..
menu options.

- Import commands from other PC Remote Control files, including the ones from
version 3.

- Increased list of available origins for remote control, including:

  * Serial port, now including LIRC type devices.
  * Keyboard.
  * TCP/IP connection.
  * AVerMedia TV Series Remote.
  * BestBuy EasyTV.
  * Other devices compatibility under development.

- Test capability of the origin, with visualization of the incoming values for
debugging purposes.

- Improved command recognition with additional options for especial behaviours.

- Selectable sound file to play for every remote command when it arrives.

- On Screen Display of the command remote, name or corresponding action.

- DDE and TCP/IP servers included, allowing other applications to receive the
command information and action description for additional command processing.


OVERVIEW
========

PC Remote Control lets you remotely control your computer from several origins,
including the serial port (RS-232), keyboard, TCP/IP and other devices
specifically designed for remote control. The main purpose of this program is to
control the computer in the same manner as you do with the TV, VCR, HiFi and
similar equipment with a simple infrared remote. The widespread use of the
computer for audio MP3 and video DVD playing can make this program a perfect
complement to your multimedia system.

The actions available are:

 - Key press simulation. You can specify Alt, Ctrl or Shift modifiers.
 - Mouse movement and click control.
 - Execution of external applications.
 - PostMessage API function access to send Windows type messages.
 - Volume control.
 - Computer log off, reboot or shutdown.
 - Windows management.
 - On Screen Display of system parameters or free text.

After a short learning process, PC Remote Control can recognize the incoming
commands from the selected origin and then simulates the action corresponding to
that command.

Devices that have been proved to run well with this software:
 - Serial port based devices:
   * UIR, Irman (evation.com)
   * Custom circuit with SSI chips or a MC68HC11 MCU version
   * IrDA transceivers, external or motherboard versions
   * X10 MouseRemote (x10.com)
   * REALmagic Remote Control (sigma-designs.com)
   Devices that may work as well:
   * Anir Multimedia Magic (animax.no)
   * Silitek SM-1000 (silitek.com)
   Discontinued products or hard to find:
   * Tekram AV-100
   * Packard Bell Fast Media
   * AST/Logitech Computer Remote Control

 - Any Windows compatible keyboard

 - Any TCP/IP server, for example WinLIRC

 - AVerMedia TV Series Remote


REQUIREMENTS
============

Windows 95, 98, NT4, 1 MB free on hard disk.


INSTALLATION
============

 - Unzip the contents of the compressed file PCREMOTE4B.ZIP to an empty folder.
If you don't have a decompression utility, use www.winzip.com.
 - By default, PC Remote Control registers itself in the Windows registry so
that everytime Windows starts, it will be automatically launched. You can
disable this auto load in the program Settings.


LIST OF FILES
=============

  PCREMOTE.EXE   Executable file
  README.TXT     This file
  MyMsgList.txt  Example of custom message list for Winamp


REGISTRATION
============

If you find PC Remote Control useful, and continue using it, you are required to
register it with 18 euro or $19 (US). Registration gives access to all the
program features.

Register online at http://www.shareit/programs/101185.htm


LICENSE AND LEGAL INFORMATION
=============================

Shareware Version

Evaluation and Registration

PC Remote Control is a shareware program. That means that you can use it
to evaluate, and if you find it useful and continue to use it you are
obligated to register it with the author as described in the section
Registration. Quantity discounts are available. When payment is received
you will receive a registered key access of the latest version of PC Remote
Control.


Registered Version

One registered copy of PC Remote Control may either be used by a single
person who uses the software personally on one or more computers, or
installed on a single workstation used nonsimultaneously by multiple
people, but not both.

You may access the registered version of PC Remote Control through a
network, provided that you have obtained individual licenses for the
software covering all workstations that will access the software through
the network.  For instance, if 8 different workstations will access PC
Remote Control on the network, each workstation must have its own PC
Remote Control license, regardless of whether they use PC Remote Control
at different times or concurrently.


Disclaimer of Warranty

THIS SOFTWARE AND THE ACCOMPANYING FILES ARE PROVIDED "AS IS" AND WITHOUT
WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER WARRANTIES
WHETHER EXPRESSED OR IMPLIED. I DO NOT WARRANT THAT THE FUNCTIONS
CONTAINED IN THE SOFTWARE WILL MEET YOUR REQUIREMENTS, OR THAT THE
OPERATION OF THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR-FREE, OR THAT
DEFECTS IN THE SOFTWARE WILL BE CORRECTED. FURTHERMORE, I DO NOT WARRANT
OR MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE RESULTS OF THE USE OF
THE SOFTWARE OR ITS DOCUMENTATION IN TERMS OF THEIR CORRECTNESS, ACCURACY,
RELIABILITY, OR OTHERWISE.


CONTACT AUTHOR
==============

 http://www.pcremotecontrol.com

 Moises Cambra Aliaga
 cambra@spainmail.com
 Poeta Leon Felipe 29, 4 A
 E-50015 ZARAGOZA
 Spain

