================================================
		Welcome to uICE 
     The Universal Infrared Control Engine
================================================


Copyright � 1999-2001 Christian Mueller, G-Ware
http://gware.virtualave.net
gware@gware.virtualave.net


>> Please turn on word wrap to read this dokument! <<


Contents
========

 Overview
 Disclaimer
 System requirements
 Installation instructions
 Upgrading from previous versions
 Known bugs and issues
 Version history




Overview
========

uICE remotely controls many Windows procedures such as executing/closing applications, simulating keyboard input, adjusting audio volume and shutting down your machine by receiving commands from infrared or fm remote receiver hardware connected to your computer. Control your Windows system with remote controls from TV sets or other home theater equipment! 

The HotKey features in uICE even allow system control without any hardware.

uICE uses a plugin library technology for hardware access. If you are familiar in programming, you may create your own plugin for special hardware not included in the plugin package. Contact the author for development informations.


DISCLAIMER
==========

See file 'License.txt'


System requirements
===================

- Windows 95/98, Windows 2000/NT5 or Windows NT4
- Common Controls (comctl32.dll) v4.71 or higher (included with Microsoft Internet Explorer 4.0 or higher)
- Microsoft Foundation Classes and runtime library files (mfc42.dll, msvcrt.dll) located in your system directory (not included to decrease download size). The package is available at ftp://ftp.simtel.net/pub/simtelnet/win95/dll/mfc4261.zip 


For remote control functions ( HotKeys are available without hardware ):
- home made or commercial infrared receiver supported by the included plugins, or a custom plugin for your special hardware
- remote control


Installation instructions
==========================

Run setup.exe and follow the instructions on the screen.
Please do not install the shareware version over existing freeware versions. You would lose the ability to uninstall the advertising components of the freeware version.

Make sure the MFC files (mfc42.dll, msvcrt.dll) are installed in your system directory. These files are libraries used by many Microsoft and other applications, so you should already have it. A complete package is available at ftp://ftp.simtel.net/pub/simtelnet/win95/dll/mfc4261.zip 


Upgrading from previous versions
================================

If you have a previous version of uICE installed, it is strongly recommended to uninstall it. To use your existing configuration in the new version, save it as a preset, uninstall the previous version and import it again after setup.

This version does not store its action configuration in the registry like older ones and the preset file format and naming has been changed. However, you can still import old presets, but you should verify the configuration after importing.


Known bugs and issues
=====================

Minimized windows cannot be restored without using the "Restore application" action.

Direct Draw or OpenGL full screen applications running in exclusive mode (3D games) will minimize when the OnScreenDisplay pops up


Version History
===============

See file 'History.txt'