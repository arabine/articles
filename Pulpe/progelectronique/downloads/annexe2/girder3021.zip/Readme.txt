
   Girder 3.0
   Copyright 2000 (c) Ron Bessems


   Disclaimer

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 


   License and costs

   Girder is a free program, as defined in the file copying.txt.
   If you want to include Girder on any distribution 
   media, any internet site I would like to know.


   Installing

   Girder is very easy to install, either use the zipped version
   and install Girder into some subdirectory, or use the install
   version available on my homepage. Run Girder and set your 
   hardware type in the settings dialog. And you're off. For more
   information look at the help file.

   -=NEW=- Pre-made groups -=NEW=-

   Teemu has offered his time to keep a pre-made group database
   on the internet. Here you can find groups for Girder that have
   been setup for you, just download the one you need and import!
   Teemu's site can be found at:

      http://www.kolumbus.fi/hummer/girder/

   If you want to contribute to the database mail the exported group
   to Teemu.

      teemu.hummer@kolumbus.fi
  

   Localisation

   Girder is fully internationalizable this has been done for 
   serveral languages by various people over the globe. If your
   language isn't included, you could translate Girder yourself.
   I've written a tool to assist in the translation, it's 
   available on my homepage. Of course once you translated 
   Girder you could send me the translation, so I can include it
   in the distribution. 

   It's also possible to translate the helpfile of Girder.
   Uwe Heidrich was the first to offer his assistance, and he 
   translated the helpfile to German!

   Any of these translation will give you eternal fame and glory 
   in the thanks section and the gratitude of thousands of people
   in your country.


   Updates

   Girder is continuously being developed by me, updates and
   new plugins will be made available via my homepage. 


   Novel Ideas and applications

   If you've got a great way to use Girder I would like to know
   so I can tell other people the superb way in which Girder can
   be applied.
  
   
   Creating Plugins

   The plugins for Girder can be written in any language that 
   supports C/C++ style STDCALLs and DLLs like Borland Delphi, 
   MS Visual C++ etc. If you've written good plugins that are
   of use to mandkind don't hesitate to send them to me. Either
   in source or binary form. Be sure to download the developers
   package from my homepage for examples how to make the 
   plugins   
   
   

   Contact and Homepage

   My homepage is
   Http:/www.stack.nl/~stilgar

   My email address is
   <R.E.M.W.Bessems@stud.tue.nl> or <stilgar@stack.nl>
      
   I hope you enjoy Girder, if so I would like to know. Any
   suggestions, comments or bugreports are welcome.


   Best Wishes,

   Ron




   All products mentioned are trademarks or registered trademarks 
   of their respective manufacturers.
