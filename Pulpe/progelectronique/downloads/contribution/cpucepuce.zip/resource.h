//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CPucePuce.rc
//
#define IDD_MAIN                        102
#define IDS_APP_TITLE                   103
#define IDI_PUCE                        107
#define IDC_CPUCEPUCE                   109
#define IDB_PUCE                        130
#define IDC_VERSION_EDIT                1000
#define IDC_DATA_EDIT                   1001
#define IDC_RESTE_EDIT                  1003
#define IDC_TOTAL_EDIT                  1004
#define IDC_VCC_COMBO                   1005
#define IDC_RW_COMBO                    1006
#define IDC_CLK_COMBO                   1007
#define IDC_RESET_COMBO                 1008
#define IDC_ES_COMBO                    1009
#define IDC_DETEC_COMBO                 1010
#define IDC_VPP_COMBO                   1011
#define IDC_LPT_COMBO                   1012
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
