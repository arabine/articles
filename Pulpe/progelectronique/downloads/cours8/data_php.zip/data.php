
<HTML>
<HEAD>
<meta http-equiv="refresh" content="10"; url="http://www.programmationworld.com/temp/data.php">
</HEAD>
<body>
<table align=center>
<tr>
<td align=center>
<img src="maison.jpg" width="573" height="381" alt="" border="0">
<br><b><u>Plan des capteurs de la maison.</u></b>
<br>
<br>
Capteur 1 : 
<?
$Fnm = "data.txt";
if (file_exists($Fnm)) 
{
 $inF = fopen($Fnm,"r");
 while (!feof($inF))
   echo fgets($inF, 4096);
 fclose($inF);
}
?>
</td>
</tr>
</table>
</body>
</html>