Accueil=html\intro.htm		; Page accueil
Pub=html\chap2.htm		; Pub pour Naheulbeuk !