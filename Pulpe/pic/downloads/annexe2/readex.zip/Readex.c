#include <stdio.h>
#include <string.h>
#include <math.h>
#include "readex.h"

int main(int args, char** argv)
{
	FILE *fp, *out;
	char filename[20];
	char *fichier;
	bool ret;
	int i;
	long int taille;
	char *ans;
	
	if(args!=2)
	{
		printf("La syntaxe de la commande est incorrecte.\n%s",usage);
		return 1;
	}
	
	
	// Quelques initialisations
	for(i=0;i<1024;i++)
	{
		pic.flash[i][0]=63;
		pic.flash[i][1]=255;
	}
	
	strcpy(filename, argv[1]);
	
	printf("Ouverture du fichier %s\n",filename);
	fp = fopen(filename,"r");
	if(!fp)
	{
		printf("Impossible d'ouvrir le fichier %s\n",filename);
		return 1;
	}
		
	/* On range tout le fichier dans un tableau */
	
	taille = filesize(fp);
	if(taille<=11)
	{
		// Le fichier doit au moins contenir la ligne de fin de fichier
		printf("Le contenu du fichier est trop faible.\n");
		return 1;	
	}

	printf("taille fichier : %ld octet(s)\n",taille);
	
	fichier = (char *) calloc( taille,sizeof(char));

	if (fichier == NULL)
	{
       printf("Pas assez de memoire pour charger le fichier.\n");
       return 1;
    }

	fread(fichier, sizeof(unsigned char), taille, fp);
	
	fclose(fp);
	
	taille = strlen(fichier); /* On remet la taille � jour, qui peut �tre fausse dans certains cas */
	
	printf("Fichier ouvert\nValidation du format Intel...\n");
	ret = verifIntel(fichier,taille);
	if(ret==true)
	{
		printf("Fichier valide\n");
		out=fopen("out.txt","w");
	
		fprintf(out, "Espace m�moire :\n");
		fprintf(out, "---------------------------\n");
		fprintf(out, "Adresse\tDonnee\tCode asm\n");
		
		for(i=0;i<1024;i++)
		{
			fprintf(out, "%d\t",i);
			
			fprintf(out, "%2.2X",pic.flash[i][0]);
			fprintf(out, "%2.2X",pic.flash[i][1]);
			
			ans = (char *)malloc(20*sizeof(char));
			ans = dasm(pic.flash[i][0],pic.flash[i][1]);
			
			fprintf(out, "\t%s\n",ans);
				
		}
		fclose(out);
	}
	else
		printf("Fichier non valide\n");
	
	
	free(fichier);
	return 0;
}

/**
 * Renvoie le code assembleur du codeop pass� en param�tre
 */
char *dasm(unsigned char high, unsigned char low)
{
	unsigned short int code, temp=0;
	int i;
	bool ok=false;
	int codeOk;
	char *asmcode;
	char buffer[10];
	
	asmcode = (char *)calloc(20,sizeof(char));
	temp = (unsigned short int)high;
	temp=temp<<8;
	code = temp + low;

	// On scan les 35 codes op pour trouver le bon
	for(i=0;i<35;i++)
	{
		if((code & HexToInt(opcodes[i][0]))==HexToInt(opcodes[i][1]))
		{
			ok = true;
			codeOk = i;
		}
	}
	
	// code non trouv�, il y a une erreur quelque part...
	if(!ok)
		return "**OPCODE ERROR**";
	
	strcat(asmcode,opcodes[codeOk][2]);
	strcat(asmcode,"\t");
	
	// ensuite, on recherche et on construit les op�randes
	if(HexToInt(opcodes[codeOk][3])==1)
	{
		strcat(asmcode,"0x");
		itoa(code & 0x7F,buffer,16);
		strcat(asmcode,buffer);
		strcat(asmcode,",0x");
		itoa((code & 0x80)>>7,buffer,16);
		strcat(asmcode, buffer);
		
	}
	else	if(HexToInt(opcodes[codeOk][3])==2)
			{
				strcat(asmcode,"0x");
				itoa(code & 0x7F,buffer,16);
				strcat(asmcode,buffer);
				strcat(asmcode,",0x");
				itoa((code & 0x380)>>7,buffer,16);
				strcat(asmcode, buffer);
			}
			else	if(HexToInt(opcodes[codeOk][3])==3)
					{
						strcat(asmcode,"0x");
						itoa(code & 0xFF,buffer,16);
						strcat(asmcode, buffer);
					}
					else	if(HexToInt(opcodes[codeOk][3])==4)
							{
								strcat(asmcode,"0x");
								itoa(code & 0x7FF,buffer,16);
								strcat(asmcode, buffer);
							}
							else	if(HexToInt(opcodes[codeOk][3])==5)
									{
										strcat(asmcode,"0x");
										itoa(code & 0x7F,buffer,16);
										strcat(asmcode, buffer);
									}
	return asmcode; // si 6 = pas d'op�randes ! on retourne donc le mn�monique sans op�randes
}


/**
 * Renvoie true si le fichier est valide, false autrement
 */
bool verifIntel(char *fichier, long int taille)
{
	char *file;
	char *separateurs = SEPARATEUR;
	char *p;
	bool ret,isEndfile=false;
	
	file = (char *)calloc(taille,sizeof(char));
	
	strcpy(file,fichier);

	/* on va maintenant d�couper par lignes */
	
	//premier appel, renvoie la premi�re ligne
    p = strtok(file, separateurs);
    do
    {
      	if(strcmp(p,":00000001FF"))
      	{
      		printf("%s",p);
      		ret = verifLigne(p);
      		if(ret==true)
				printf(" --> ligne valide\n");
			else
			{
				printf(" --> ligne fausse\n");
				return false;
			}
      	}
      	else
			isEndfile = true;
    }
    while((p = strtok(NULL, separateurs))!= NULL);

	if(isEndfile)
		return true;
	else
	{
		printf("Pas d'indication de fin de fichier\n");
		return false;
	}
}

/**
 * Valide une ligne
 */
bool verifLigne(char *ligne)
{
	int taille,i,j,k;
	unsigned long int _databits;
	unsigned int somme=0;
	char *dataBits, *offset, *dataType, *checksum;
	char *var;
	int deb,fin;
	// Premi�re v�rification, et la plus simple, on regarde si
	// la ligne commence par un deux points
	if(ligne[0]!=':')
		return false;
	
	// On enregistre les �l�ments de la ligne pour les v�rifier
	
	taille = strlen(ligne);
	
	// On r�serve les espaces m�moires
	dataBits = (char *)malloc(2*sizeof(char));
	offset = (char *)malloc(4*sizeof(char));
	dataType = (char *)malloc(2*sizeof(char));
	checksum = (char *)malloc(2*sizeof(char));
	
	dataBits = mid(ligne,1,2);
	offset = mid(ligne,3,6);
	dataType = mid(ligne,7,8);
	checksum = mid(ligne,taille-2,taille-1);
	
	_databits = HexToInt(dataBits);

	// On teste ici la longueur des donn�es
	if(!(_databits==(taille-11)/2))
		return false;
	
	// On fait la somme des octets de toute la ligne (hormis le checksum et les deux points
	for(i=1;i<=taille-4;i=i+2)
		somme += HexToInt(mid(ligne,i,i+1));
	
	// On teste le checksum...
	if(HexToInt(checksum)!=CalculateChecksum(somme))
		return false;
	
	// A partir de maintenant, la ligne est bonne on stocke les donn�es � l'adresse voulue
	
	
	if(HexToInt(dataType)!=0)
		return true;
	
	
	j=0;
	deb = HexToInt(offset)/2;
	fin = deb+(_databits)/2-1;
	for(i=deb;i<=fin;i++)
	{
		var = mid(ligne,9+j,10+j);
		pic.flash[i][1] = HexToInt(var);
		var = mid(ligne,11+j,12+j);
		pic.flash[i][0] = HexToInt(var);
		j=j+4;
	}
	return true;
}

/**
 * Retourne le checksum d'une valeur pass�e en param�tre
 */
unsigned char CalculateChecksum(int val)
{
	// On transforme en binaire et on garde les 8 premiers bits
	int temp=val;
	if(temp>=256)
	{
		while(temp>=256)
			temp -= 256;
	}
	return (256-temp);
}


/**
 * Retourne une partie d'une chaine d�limit�e par deux positions
 */
char *mid(char *chaine, int debut, int fin)
{
	int taille;
	char *buf;
	int i;
	
	taille = fin-debut+1;
	
	if(taille<=0 || taille>=strlen(chaine))
	{
		printf("\nAppel non valide.\n");
		return NULL;
	}
	
	buf = (char *)calloc(taille+1,sizeof(char));
	
	for(i=0;i<taille;i++)
		buf[i] = chaine[debut+i];
	buf[taille]='\0';	// on termine la chaine de caract�res
	return buf;
}

/**
 * Convertit une chaine de caract�res hexad�cimaux en valeur enti�re
 */
unsigned long int HexToInt(char *string)
{
	int i,j;
	unsigned long int val=0;
	char a;
	
	j = strlen(string)-1;
	for(i=0;i<strlen(string);i++)
	{
		a = asciiToHex(string[i]);
		val = val + a*pow(16,j);
		j--;
	}
	return val;
}

/**
 * Convertit un caract�re ASCII en valeur hexad�cimale
 */
char asciiToHex(char c)
{
	if(c<58 && c >47)
		return c-48;
	else if(c<71 && c>64)
			return c-55;
		else if(c<103 && c>96)
				return c-87;
			else
				return 0;
}


/**
 * Retourne la taille du fichier en octets
 */
long filesize(FILE *stream)
{
	long curpos,length;

	curpos = ftell(stream); /* garder la position courante */
	fseek(stream, 0L, SEEK_END);
	length = ftell(stream);
	fseek (stream, curpos, SEEK_SET); /* restituer la position */
	
	return length;
}
