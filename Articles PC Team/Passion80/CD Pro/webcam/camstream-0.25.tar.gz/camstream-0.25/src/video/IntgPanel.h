#ifndef INTGPANEL_HPP
#define INTGPANEL_HPP

#include "CamPanel.h"

class CIntgPanel: public CCamPanel
{
   Q_OBJECT
private:
   CCamPanel *pYUVPanel, *pDiffPanel;
   int RefreshCountdown, Refreshes;

   void Calculate(int n, void *dst, void *src);

protected slots:   
   virtual void UpdatePanel();

public:
   CIntgPanel(CCamPanel *yuv_panel, CCamPanel *diff_panel, 
              const char *name = "intg.yuv", 
              const char *desc = "YUV Integrator");

   void SetRefresh(int n);

public slots:
};

#endif
