#ifndef RGBSHOWPANEL_HPP
#define RGBSHOWPANEL_HPP

#include <qimage.h>

#include "CamPanel.h"

class CRGBShow: public CCamPanel
{
   Q_OBJECT
private:
   CCamPanel *pBase;
   
public:
   CRGBShow(CCamPanel *yuv_panel, const char *name = "show.rgb", const char *desc = "Showing RGB version");

public slots:
   void UpdatePanel();
};


#endif
