
#ifndef DIFFPANEL_HPP
#define DIFFPANEL_HPP

#include "CamPanel.h"

class CDiffPanel: public CCamPanel
{
   Q_OBJECT
private:
   CCamPanel *pPanel1, *pPanel2;
   int Pixels, Scale;

   void Calculate(int n, void *dst, void *src1, void *src2);

public:
   CDiffPanel(CCamPanel *p1, CCamPanel *p2, int scale,
              const char *name = "difference", const char *desc = "Difference");

public slots:
   virtual void UpdatePanel();
   virtual void SetSize(const QSize &new_size);
};

#endif
