#define __ASSEMBLY__
#include <linux/linkage.h>

#define Number 8(%ebp)
#define Dst    12(%ebp)
#define Src1   16(%ebp)
#define Src2   20(%ebp)

