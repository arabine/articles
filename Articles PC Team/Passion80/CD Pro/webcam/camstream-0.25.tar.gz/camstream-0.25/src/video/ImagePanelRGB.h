#ifndef IMAGEPANELRGB_HPP
#define IMAGEPANELRGB_HPP

#include "VideoDevice.h"
#include "CamPanel.h"

class CImagePanelRGB: public CCamPanel
{
   Q_OBJECT
private:
   CVideoDevice *pVideo;

private slots:
   void UpdateImage();

public:
   CImagePanelRGB(CVideoDevice *pVideo, QWidget *parent = 0, const char *name = 0);
   
   // overloaded from QWidget
   void hideEvent(QHideEvent *);
   void showEvent(QShowEvent *);
};

#endif
