#ifndef BASICPANEL_HPP
#define BASICPANEL_HPP

#include "CamPanel.h"

class CBasicPanel: public CCamPanel
{
   Q_OBJECT
public:
   CBasicPanel(const char *panel_name, const char *desc, int panel_type, QWidget *parent = 0, const char *name = 0);
   ~CBasicPanel();

   void SetImage(int n, const QImage &new_image, bool deep = FALSE);
   
public slots:   
   virtual void SetSize(const QSize &ns);
};

#endif
