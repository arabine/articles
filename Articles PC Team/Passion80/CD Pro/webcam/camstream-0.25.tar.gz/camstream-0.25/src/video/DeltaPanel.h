#ifndef DELTAPANEL_HPP
#define DELTAPANEL_HPP

#include "CamPanel.h"
#include "VideoDevice.h"

class CDeltaPanel: public CCamPanel
{
private:
   CVideoDevice *pVideo;
   int Pixels;

   void Calculate(int n, void *dst, void *src1, void *src2);
   
public:
   CDeltaPanel(CVideoDevice *video);

   virtual void UpdatePanel();   
};

#endif
