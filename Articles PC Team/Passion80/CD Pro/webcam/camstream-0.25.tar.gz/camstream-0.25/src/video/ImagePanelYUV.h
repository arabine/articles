#ifndef IMAGEPANELYUV_HPP
#define IMAGEPANELYUV_HPP

#include "VideoDevice.h"
#include "CamPanel.h"

class CImagePanelYUV: public CCamPanel
{
   Q_OBJECT
private:
   CVideoDevice *pVideo;

private slots:
   void UpdateImage();

public:
   CImagePanelYUV(CVideoDevice *pVideo, QWidget *parent = 0, const char *name = 0);
   
   // overloaded from QWidget
   void hideEvent(QHideEvent *);
   void showEvent(QShowEvent *);
};

#endif
