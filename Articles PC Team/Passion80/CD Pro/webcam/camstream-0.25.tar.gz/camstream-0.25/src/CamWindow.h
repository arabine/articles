#ifndef CAMWINDOW_HPP
#define CAMWINDOW_HPP

#include <qmainwindow.h>


class CCamWindow: public QMainWindow
{
   Q_OBJECT
private:

protected:
   CCamWindow(QWidget *parent = 0, const char *name = 0);

public:
   ~CCamWindow();
};   



#endif
