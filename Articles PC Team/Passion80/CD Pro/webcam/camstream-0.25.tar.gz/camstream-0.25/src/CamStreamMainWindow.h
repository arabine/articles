#ifndef CAMMAINWINDOW_HPP
#define CAMMAINWINDOW_HPP

#include <qlist.h>
#include <qmainwindow.h>

#if HAVE_CONFIG_H
#include "config.h"
#endif

class CCamStreamMainWindow: public QMainWindow
{
   Q_OBJECT
private:
   QWidget *Workspace;
   
private slots:
   // Menu options 
   void FileOpenNewViewer();
   void FileOpenNewEncoder();
   void FileOpenNewReceiver();
   
public:
   CCamStreamMainWindow();
   ~CCamStreamMainWindow();
};

#endif
