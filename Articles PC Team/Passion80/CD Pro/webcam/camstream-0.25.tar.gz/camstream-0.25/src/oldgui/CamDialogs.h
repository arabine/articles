/**********************************************************************

	--- Qt Architect generated file ---

	File: CamDialogs.h
	Last generated: Sat Dec 18 07:12:38 1999

 *********************************************************************/

#ifndef CCamDialogs_included
#define CCamDialogs_included

#include "CamDialogsData.h"

#include "PhilipsControl.h"
#include "SizeFrame.h"
#include "VideoControl.h"
#include "VideoDevice.h"
#include "VideoTuning.h"

class CCamDialogs: public CCamDialogsData
{
    Q_OBJECT
private:
   CVideoDevice *pVideo;

public:
   CSizeFrame *pSizeFrame;
   CVideoControl *pVideoControl;
   CVideoTuning *pVideoTuning;
   CPhilipsControl *pPhilips;

   CCamDialogs(CVideoDevice *_video, QWidget* parent = NULL, const char* name = NULL);
   virtual ~CCamDialogs();
};
#endif // CCamDialogs_included
