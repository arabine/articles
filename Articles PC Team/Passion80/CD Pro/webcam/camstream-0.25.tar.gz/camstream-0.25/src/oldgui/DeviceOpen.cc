/**********************************************************************

	--- Qt Architect generated file ---

	File: DeviceOpen.cpp
	Last generated: Wed Jul 19 03:39:04 2000

 *********************************************************************/

#include "DeviceOpen.h"

#define Inherited CDeviceOpenData

CDeviceOpen::CDeviceOpen(QWidget* parent, const char* name)
	: Inherited( parent, name )
{
   setCaption( "Open Device" );
   DeviceName->setFocus();
}


CDeviceOpen::~CDeviceOpen()
{
}

QString CDeviceOpen::GetFileName()
{
   QString s;
   
   s = DeviceName->text();
   return s;
}
