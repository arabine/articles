/**********************************************************************

	--- Qt Architect generated file ---

	File: NewViewer.h
	Last generated: Sun Aug 13 17:52:46 2000

 *********************************************************************/

#ifndef CNewViewer_included
#define CNewViewer_included

#include <qsize.h>

#include "VideoCollector.h"

#include "NewViewerData.h"

class CNewViewer : public CNewViewerData
{
    Q_OBJECT
private:
    QSize InitSize;
    CVideoCollector *pCollector;

protected:
   void ClickedOnSize(int);

public:
    CNewViewer(CVideoCollector *coll, QWidget* parent = NULL, const char* name = NULL);
    virtual ~CNewViewer();
    
    CVideoDevice *GetVideoDevice() const;
    QSize GetInitialSize() const;
};
#endif // CNewViewer_included
