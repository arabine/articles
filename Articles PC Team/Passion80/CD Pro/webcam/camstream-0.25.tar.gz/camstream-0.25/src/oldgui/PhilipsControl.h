/**********************************************************************

	--- Qt Architect generated file ---

	File: PhilipsControl.h
	Last generated: Wed Nov 15 22:11:49 2000

 *********************************************************************/

#ifndef CPhilipsControl_included
#define CPhilipsControl_included

#include <qtimer.h>

#include "VideoDevice.h"
#include "PhilipsControlData.h"

class CPhilipsControl : public CPhilipsControlData
{
    Q_OBJECT
private:
   int UserAgc, UserShutter, UserCompression;
   CVideoDevice *pVideo;
   QTimer *pAGCTimer;

   void ReadCompression();

protected:
   void SaveUserClicked();
   void RestoreUserClicked();
   void RestoreFactoryClicked();

   void ClickedAGCAuto(bool on);
   void MovedAGC(int);
   void ClickedShutterAuto(bool on);
   void MovedShutter(int);
   void ClickedCompression(int);

protected slots:
   void AGCTick();

public:
   CPhilipsControl(CVideoDevice *_video, QWidget* parent = NULL, const char* name = NULL);
   virtual ~CPhilipsControl();
   
   void hide(); // overloaded
   void show(); // overloaded
};

#endif // CPhilipsControl_included
