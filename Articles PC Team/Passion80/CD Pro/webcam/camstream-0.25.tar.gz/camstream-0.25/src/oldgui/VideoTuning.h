/**********************************************************************

	--- Qt Architect generated file ---

	File: VideoTuning.h
	Last generated: Tue Oct 17 04:10:34 2000

 *********************************************************************/

#ifndef CVideoTuning_included
#define CVideoTuning_included

#include "VideoTuningData.h"
#include "VideoDevice.h"

class CVideoTuning: public CVideoTuningData
{
   Q_OBJECT
private:
   CVideoDevice *pVideo;
   int MaxInputs;
   CVideoDeviceInput *pInput;
   CVideoDeviceTuner *pTuner;

   void DisplayFrequency(float freq);

private slots:
   void ClickedInput(int n);
   void ClickedTuner(int n);
   void MovedSlider(int n);

public:
   CVideoTuning(CVideoDevice *_video, QWidget* parent = NULL, const char* name = NULL);
   virtual ~CVideoTuning();
};

#endif // CVideoTuning_included
