/**********************************************************************

	--- Qt Architect generated file ---

	File: DeviceOpen.h
	Last generated: Wed Jul 19 03:39:04 2000

 *********************************************************************/

#ifndef CDeviceOpen_included
#define CDeviceOpen_included

#include "DeviceOpenData.h"

class CDeviceOpen : public CDeviceOpenData
{
    Q_OBJECT

public:
   CDeviceOpen(QWidget* parent = NULL, const char* name = NULL);
   virtual ~CDeviceOpen();
    
   QString GetFileName();
};
#endif // CDeviceOpen_included
