/**********************************************************************

	--- Qt Architect generated file ---

	File: VideoControl.h
	Last generated: Sat Dec 18 06:37:21 1999

 *********************************************************************/

#ifndef CVideoControl_included
#define CVideoControl_included

#include <sys/types.h>
#include <linux/videodev.h>

#include "VideoControlData.h"
#include "VideoDevice.h"

class CVideoControl: public CVideoControlData
{
    Q_OBJECT
private:
   CVideoDevice *pVideo;
   int brightness, contrast, gamma, colour;
   int org_b, org_o, org_g, org_c;

   void GetControl(bool First = false);

protected:
   void ChangedBrightness(int value);
   void ChangedContrast(int value);
   void ChangedGamma(int value);
   void ChangedColour(int value);

public:
   CVideoControl(CVideoDevice *_video, QWidget* parent = NULL, const char* name = NULL);
   virtual ~CVideoControl();

public slots:
   void RestoreDefaults();
};
#endif // CVideoControl_included
