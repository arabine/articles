/**********************************************************************

	--- Qt Architect generated file ---

	File: SizeFrame.h
	Last generated: Sat Dec 18 06:17:46 1999

 *********************************************************************/

#ifndef CSizeFrame_included
#define CSizeFrame_included

#include <sys/types.h>
#include <linux/videodev.h>

#include <qbutton.h>
#include <qsize.h>

#include "SizeFrameData.h"
#include "VideoDevice.h"

class CSizeFrame : public CSizeFrameData
{
    Q_OBJECT
private:
   CVideoDevice *pVideo;

   QSize size, org_size;
   int fps, org_fps;

   void GetCam(bool First = FALSE);
   void SetCam();

private slots:
   void SizeChanged(const QSize &);
 
protected:
   void ClickedSize(int);
   void ClickedRate(int);
   void ChangedRate();

public:
    CSizeFrame(CVideoDevice *_video, QWidget* parent = NULL, const char* name = NULL);
    virtual ~CSizeFrame();
};
#endif // CSizeFrame_included
