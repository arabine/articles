#ifndef VIDEOCOLLECTOR_HPP
#define VIDEOCOLLECTOR_HPP

#include <qlist.h>

#if HAVE_CONFIG_H
#include "config.h"
#endif

#include "VideoDevice.h"

class CVideoCollector
{
private:
   static CVideoCollector *Collector;
   QList<CVideoDevice> Devices;
   
   CVideoCollector();
   void Scan();

public:
   static CVideoCollector *Instance();

   int NumberOfVideoDevices();
   CVideoDevice *GetVideoDevice(int n);
};

#endif
