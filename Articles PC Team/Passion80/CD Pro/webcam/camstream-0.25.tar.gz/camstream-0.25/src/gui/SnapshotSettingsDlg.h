#ifndef SNAPSHOTSETTINGSDLG_HPP
#define SNAPSHOTSETTINGSDLG_HPP

#include <qcolor.h>

#include "FTPSettings.h"
#include "SnapshotSettings.h"
#include "VideoOptions.h"

class CSnapshotSettingsDlg: public CSnapshotSettings
{
   Q_OBJECT
private:
   struct SVideoOptions *pVOpts;
   CFTPSettings *pFTPSettings;
   QColor TextColor;
   QFont TextFont;
   QString FileFormat;

protected:
   /* overloaded */
   void ClickedOK();
   void ClickedColor();
   void ClickedFont();
   void ClickedFTP();

public:   
   CSnapshotSettingsDlg(struct SVideoOptions *opts);

signals:
   void FTPSettingsUpdated();
};



#endif
