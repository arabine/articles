#include <windows.h>
#include <shlobj.h>			// necessary when using the "browse" dialog
#include <process.h>
#include <stdio.h>
#include <time.h>
#include <commctrl.h>

#include "gen.h"
#include "resource.h"
#include "winampcmd.h"

#define Version "v2.53"

// Winamp Universal Infrared Plugin 
// Ties Bos, PE1PUY.
// tbos@huygens.org
// Initial version by Ties Bos, 1998.
// Parts by M.Kiesel 1999
// More stuff by Ties in 1999 too.
// update 03-28-1999, finlux, luxor and mitsubishi support added.
// update 04-01-1999, 
//		added some new features (repeat toggle, close winamp, next/prev playlist and finlux/luxor remote support.
//		when timeout-function is disabled the OverlappedIO function will now block so the plugin eats NO idle CPU time at all then.
// update 06-27-1999,
//		added tab control as number of options grew too big.
//		added IDC_PREVPLAYLIST, IDC_NEXTPLAYLIST, IDC_TOGGLETIME and IDC_FADEOUT controls.
//		shortened start-repeat-delay. This speeds up the start of volume-up/down repeating and
//		hopefully solves problem people have in entering numbers with two succeeding digits that are the same.
//		.ini file is written after each time ok or apply is pressed in the settings dialog now.
//		removed .wav playing on each button press. Maybe I'll add right-click on all buttons in a bit 
//		and allow setting of a filename to play per button. Management like it was is horrible.
// update 08-14-1999 to 08-23-1999.
//		equalizer window show/hide toggle.
//		playlist next/prev bugfix.
//		key already in use by 'blabla' message if learned button was already in use.
//		playlist path editable in the dialog.
//		Volume step variable. ==> In plugin.ini only for now, as VolumeSteps. Defaults to 1.
//		keyspeech with variable names.
//		scan CD to make playlist --> A different plugin exists for this, I put a link on the UIR page.
//		buttons to run an external program like 'scandisk'.
//		shorter maximum delay between repeated buttons, to allow selection of songs like '122'.
//		preset volume button (aka mute, no unmute) defaults to 0.
// update 08-14-1999 to 08-23-1999.
//		The plugin did not run on windows2000 and NT. Problem was I did not fully initialize the KeyNames array.
//		This Shows just how bad window 98 memory protection is!!
//	TODO
//		jump to file by typing starting characters of a filename with the numeric buttons like on a cellphone.


BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK NextKeyProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);
static void opencomport();
static void closecomport();
static void WriteData(HANDLE port,BYTE data);
static BOOL ReadData(HANDLE port,LPBYTE buffer,DWORD size,BOOL blocking);
static void PowerOff(HANDLE port);
static void PowerOn(HANDLE port);
int __stdcall WorkerThreadFunc(LPVOID Param);
static BOOL ShowBrowseDialog (HWND hDlg, char*text,char *ret);

HANDLE hThread;
volatile int killSwitch;
void config();
void quit();
int init();
void config_write();
void config_read();
char szAppName[] = "PE1PUY UIR Infrared Plugin";
char playlistdir[256];
char *errmsg=NULL;
int playlistnumber,changingplaylist,irenabled=1,volumesteps=1;

typedef struct {DWORD a,b;} keyType;

#define NUM_KEYS 38
char *comnames[4]={"COM1","COM2","COM3","COM4"};
char *TimeoutStrings[7]={"Disable","0.5 sec","0.8 sec","1.0 sec","1.3 sec","1.5 sec","2.0 sec"};
double TimeoutValues[7]={0,0.5,0.8,1.0,1.3,1.5,2.0};
int PluginEnabled=1,DebugEnabled=0,ConfigWaitForKey=0,comportnr=1,TimeoutOption=6,KeyBeepEnabled=1,filternoise=0,KeySpeechEnabled=0,equalizer_controlEnabled=0;
char KeySpeechFiles[NUM_KEYS][FILENAME_MAX];
char extcmds[3][FILENAME_MAX],extargs[3][FILENAME_MAX];
int presetvolume=0;
keyType lastkey;
HANDLE comPort=INVALID_HANDLE_VALUE;
HWND waitingHwnd;

#define WM_WA_IPC WM_USER
#define IPC_DELETE 101
#define IPC_PLAYFILE 100
#define IPC_STARTPLAY 102
#define IPC_SETPLAYLISTPOS 121

winampGeneralPurposePlugin plugin =
{
	GPPHDR_VER,
	"",
	init,
	config,
	quit,
};

__declspec( dllexport ) 
winampGeneralPurposePlugin * winampGetGeneralPurposePlugin()
{
	return &plugin;
}


void config()
{
	DialogBox(plugin.hDllInstance,MAKEINTRESOURCE(IDD_DIALOG1),plugin.hwndParent,ConfigProc);
}

void quit()
{
	closecomport();
	config_write();
}

void closecomport()
{
	if (comPort!=INVALID_HANDLE_VALUE)
	{
		PowerOff(comPort);
		CloseHandle(comPort);
		comPort = INVALID_HANDLE_VALUE;
		Sleep(250);
	}
}

OVERLAPPED Rov,Wov;

void opencomport()
{
	DCB comState;
	DCB newComState;
	BYTE data[2];
	int threadid;

	
		Rov.Internal=Rov.InternalHigh=Rov.Offset=Rov.OffsetHigh=0;
		Rov.hEvent=INVALID_HANDLE_VALUE;
		// create event for overlapped I/O
		Rov.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
		if (Rov.hEvent == INVALID_HANDLE_VALUE)
			return;

		Wov.Internal=Wov.InternalHigh=Wov.Offset=Wov.OffsetHigh=0;
		Wov.hEvent=INVALID_HANDLE_VALUE;
		// create event for overlapped I/O
		Wov.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
		if (Wov.hEvent == INVALID_HANDLE_VALUE)
			return;

		comPort = CreateFile(comnames[comportnr],GENERIC_READ | GENERIC_WRITE,0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED,NULL);
		
		if (comPort != INVALID_HANDLE_VALUE)
		{
			if (GetCommState(comPort,&comState))
			{
				newComState=comState;
				BuildCommDCB("9600,n,8,1", &newComState);
				newComState.fDtrControl = DTR_CONTROL_DISABLE;
				newComState.fRtsControl = RTS_CONTROL_DISABLE;

				if (SetCommState(comPort,&newComState))
				{
					PowerOff(comPort);
					Sleep(250);
					PowerOn(comPort);
					Sleep(250);
					PurgeComm(comPort,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);

					Sleep(2);
					WriteData(comPort,'I');
					Sleep(2);
					WriteData(comPort,'R');

					Sleep(100); // let's wait for the microcontrol's response

					if (ReadData(comPort,data,2,FALSE))
					{
						if ((data[0] != 'O') || (data[1] != 'K'))
						{
							errmsg="Could not initialize IR-device.\nMake sure you set the COM-port correct.\n After that, press Apply to try initialization again.\n\nOnce initialized correctly you can setup your keys.";
							SetCommState(comPort,&comState);
							PowerOff(comPort);
							CloseHandle(comPort);
							comPort = INVALID_HANDLE_VALUE;
						}
					}
					else
					{
						errmsg="Could not initialize IR-device.\nMake sure you set the COM-port correct.\n After that, press Apply to try initialization again.\n\nOnce initialized correctly you can setup your keys.";
						PowerOff(comPort);
						if (!SetCommState(comPort,&comState))
							MessageBox(plugin.hwndParent,"Restoring old state with SetCommState failed","Error",MB_ICONEXCLAMATION|MB_OK);
						else {

							CloseHandle(comPort);
						}
						comPort = INVALID_HANDLE_VALUE;
					}
				}
				else
				{
					errmsg="Could not open comport: SetCommState returned an Error";
					PowerOff(comPort);
					CloseHandle(comPort);
					comPort = INVALID_HANDLE_VALUE;
				}
			}
			else
			{
				errmsg="Could not open comport: GetCommState returned an Error";
				PowerOff(comPort);
				CloseHandle(comPort);
				comPort = INVALID_HANDLE_VALUE;
			}
		}
		else 
			errmsg="Could not initialize IR-device.\nMake sure you set the COM-port correct.\n After that, press Apply to try initialization again.\n\nOnce initialized correctly you can setup your keys.";
			switch (GetLastError()) 
				{
					case 2: errmsg="Could not open comport : port does not exist.\nMake sure the port is enabled in the BIOS and exists in\nControl Panel -> System -> Ports."; break;
					case 5: errmsg="Could not open comport : Windows denied access.\nMake sure you set the COM-port correct.\nAfter that, press Apply to try initialization again.\n\nOnce initialized correctly you can setup your keys."; break;
				}
		if (comPort!=INVALID_HANDLE_VALUE)
		{
			hThread = (HANDLE) _beginthreadex(NULL,0,(LPTHREAD_START_ROUTINE)WorkerThreadFunc,(LPVOID)&killSwitch,0,&threadid);
			SetThreadPriority(hThread,THREAD_PRIORITY_LOWEST);
		}
		else
			if (errmsg) 
				MessageBox(plugin.hwndParent,errmsg,"Error",MB_ICONEXCLAMATION|MB_OK);
			else 
				MessageBox(plugin.hwndParent,"Could not initialize IR-device.\nMake sure you set the COM-port correct.\n After that, press Apply to try initialization again.\n\nOnce initialized correctly you can setup your keys.","Error",MB_ICONEXCLAMATION|MB_OK);
}

int init()
{
	{
		char filename[512],*p;
		GetModuleFileName(plugin.hDllInstance,filename,sizeof(filename));
		p = filename+strlen(filename);
		while (p >= filename && *p != '\\') p--;
		wsprintf((plugin.description=malloc(512)),"%s "Version" (%s)",szAppName,p+1);
	}
	config_read();
	killSwitch=0;
	if (PluginEnabled) opencomport();

	return 0;
}

keyType KeyCodes[NUM_KEYS];
WPARAM KeyCommands[NUM_KEYS]={
/*IDC_PLAY*/			WINAMP_BUTTON2,
/*IDC_PAUSE*/			WINAMP_BUTTON3,
/*IDC_NEXTTRACK*/		WINAMP_BUTTON5,
/*IDC_PREVTRACK*/		WINAMP_BUTTON1,
/*IDC_FWD10*/			WINAMP_JUMP10FWD,
/*IDC_BACK10*/			WINAMP_JUMP10BACK,
/*IDC_VOLUMEUP*/		WINAMP_VOLUMEUP,
/*IDC_VOLUMEDOWN*/		WINAMP_VOLUMEDOWN,
/*IDC_FORWARD5*/		WINAMP_FFWD5S,
/*IDC_REWIND5*/			WINAMP_REW5S,
/*IDC_STOP*/			WINAMP_BUTTON4,
/*IDCKEY0-IDC_KEY9*/	IDC_KEY0,IDC_KEY1,IDC_KEY2,IDC_KEY3,IDC_KEY4,IDC_KEY5,IDC_KEY6,IDC_KEY7,IDC_KEY8,IDC_KEY9,
/*ID_SUSPEND*/			IDC_SUSPEND,
/*IDC_SHUFFLE*/			WINAMP_FILE_SHUFFLE,
/*IDC_SHUTDOWN*/		IDC_SHUTDOWN,
/*IDC_PLAYLIST*/		IDC_PLAYLIST,
/*IDC_REPEAT*/			WINAMP_FILE_REPEAT,
/*IDC_CLOSEWINAMP*/		WINAMP_FILE_QUIT,
/*IDC_VISUALPLUGIN*/	WINAMP_VISPLUGIN,
/*IDC_REMOTE*/			IDC_REMOTE,
/*IDC_FADEOUT*/			WINAMP_BUTTON4_SHIFT,
/*IDC_PREVPLAYLIST*/	IDC_PREVPLAYLIST,
/*IDC_NEXTPLAYLIST*/	IDC_NEXTPLAYLIST,
/*IDC_TOGGLETIME*/		40242,
/*IDC_OPTIONSEQ*/		WINAMP_OPTIONS_EQ,
/*IDC_EXTCMD1*/			IDC_EXTCMD1,
/*IDC_EXTCMD2*/			IDC_EXTCMD2,
/*IDC_EXTCMD3*/			IDC_EXTCMD3,
/*IDC_PRESETVOL*/		IPC_SETVOLUME
};

char *KeyNames[NUM_KEYS]={
	"Play",
	"Pause",
	"Next track",
	"Prev track",
	"Fwd 10 tracks",
	"Back 0 tracks",
	"Volume up",
	"Volume down",
	"Forward 5s",
	"Rewind 5s",
	"Stop",
	"0","1","2","3","4","5","6","7","8","9",
	"Suspend PC",
	"Toggle Shuffle",
	"Shutdown PC",
	"Load playlist",
	"Toggle Repeat",
	"Close winamp",
	"Visual plugin",
	"Remote on/off",
	"Fade out",
	"Prev playlist",
	"Next playlist",
	"Toggle time",
	"Equalizer window",
	"External Command 1",
	"External Command 2",
	"External Command 3",
	"Preset volume"
};

void
show_control(HWND hwnd,int enable,int dlgItem)
{
	hwnd= GetDlgItem(hwnd,dlgItem);
	ShowWindow(hwnd,enable?SW_SHOW:SW_HIDE);
	EnableWindow(hwnd,enable);
}

void
show_tabpage(HWND hwnd,int page)
{
	show_control(hwnd,page==0, IDC_PLAY);
	show_control(hwnd,page==0, IDC_PAUSE);
	show_control(hwnd,page==0, IDC_NEXTTRACK);
	show_control(hwnd,page==0, IDC_PREVTRACK);
	show_control(hwnd,page==0, IDC_FWD10);
	show_control(hwnd,page==0, IDC_BACK10);
	show_control(hwnd,page==0, IDC_VOLUMEUP);
	show_control(hwnd,page==0, IDC_VOLUMEDOWN);
	show_control(hwnd,page==0, IDC_FORWARD5);
	show_control(hwnd,page==0, IDC_REWIND5);
	show_control(hwnd,page==0, IDC_STOP);
	show_control(hwnd,page==2, IDC_KEY0);
	show_control(hwnd,page==2, IDC_KEY1);
	show_control(hwnd,page==2, IDC_KEY2);
	show_control(hwnd,page==2, IDC_KEY3);
	show_control(hwnd,page==2, IDC_KEY4);
	show_control(hwnd,page==2, IDC_KEY5);
	show_control(hwnd,page==2, IDC_KEY6);
	show_control(hwnd,page==2, IDC_KEY7);
	show_control(hwnd,page==2, IDC_KEY8);
	show_control(hwnd,page==2, IDC_KEY9);
	show_control(hwnd,page==2, IDC_SUSPEND);
	show_control(hwnd,page==0, IDC_SHUFFLE);
	show_control(hwnd,page==2, IDC_SHUTDOWN);
	show_control(hwnd,page==1, IDC_PLAYLIST);
	show_control(hwnd,page==0, IDC_REPEAT);
	show_control(hwnd,page==2, IDC_CLOSEWINAMP);
	show_control(hwnd,page==2, IDC_VISUALPLUGIN);
	show_control(hwnd,page==2, IDC_REMOTE);
	show_control(hwnd,page==0, IDC_FADEOUT);
	show_control(hwnd,page==1, IDC_PREVPLAYLIST);
	show_control(hwnd,page==1, IDC_NEXTPLAYLIST);
	show_control(hwnd,page==2, IDC_TOGGLETIME);
	show_control(hwnd,page==2, IDC_OPTIONSEQ);
	show_control(hwnd,page==1, IDC_PLSTDIR);
	show_control(hwnd,page==3, IDC_LIST1);
	show_control(hwnd,page==3, IDC_CHANGEFILE);
	show_control(hwnd,page==2, IDC_EXTCMD1);
	show_control(hwnd,page==2, IDC_EXTCMD2);
	show_control(hwnd,page==2, IDC_EXTCMD3);
	show_control(hwnd,page==0, IDC_PRESETVOL);
}

BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	static keyType newkeys[NUM_KEYS];
	switch (uMsg)
	{
		case WM_INITDIALOG:
			{
				int x;
				HWND hwnd;
				CheckDlgButton(hwndDlg,IDC_ENABLE,PluginEnabled?BST_CHECKED:BST_UNCHECKED);
//		CheckDlgButton(hwndDlg,IDC_DEBUG,DebugEnabled?BST_CHECKED:BST_UNCHECKED);
				CheckDlgButton(hwndDlg,IDC_EQUALIZER,equalizer_controlEnabled?BST_CHECKED:BST_UNCHECKED);
				CheckDlgButton(hwndDlg,IDC_KEYBEEP,KeyBeepEnabled?BST_CHECKED:BST_UNCHECKED);
				CheckDlgButton(hwndDlg,IDC_KEYSPEECH,KeySpeechEnabled?BST_CHECKED:BST_UNCHECKED);

				{TC_ITEM tie;
					char g_achTemp[256];  // temporary buffer for strings 
					int i;
					hwnd= GetDlgItem(hwndDlg,IDC_KEYTAB);
					tie.mask = TCIF_TEXT; 
					tie.iImage = -1; 
					tie.pszText = g_achTemp; 
	 
					for	(i = 0; i < NUM_TABS; i++) { 
						LoadString(plugin.hDllInstance, IDS_FIRST_TAB+i, g_achTemp, sizeof(g_achTemp)); 
						TabCtrl_InsertItem(hwnd, i, &tie);
					}
				}
				show_tabpage(hwndDlg,0);
					
				hwnd= GetDlgItem(hwndDlg,IDC_COMPORT);
				for (x = 0; x < 4; x++) SendMessage(hwnd,CB_ADDSTRING,0,(LPARAM) comnames[x]);
				SendMessage(hwnd,CB_SETCURSEL,(WPARAM) comportnr,0);

				hwnd= GetDlgItem(hwndDlg,IDC_TIMEOUT);
				for (x = 0; x < 7; x++) SendMessage(hwnd,CB_ADDSTRING,0,(LPARAM) TimeoutStrings[x]);
				SendMessage(hwnd,CB_SETCURSEL,(WPARAM) TimeoutOption,0);

				hwnd= GetDlgItem(hwndDlg,IDC_LIST1);
				for (x = 0; x < NUM_KEYS; x++) SendMessage(hwnd,LB_ADDSTRING,0,(LPARAM) KeyNames[x]);
				SendMessage(hwnd,LB_SETCURSEL,(WPARAM)0,0);

				for (x = 0; x < NUM_KEYS; x ++)	newkeys[x]=KeyCodes[x];
				break;
			}

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDC_HELPTEXT:
					MessageBox(hwndDlg,	"Configuration: Select comport, enable infrared control, press apply. Then, for every button under Key Settings, press it followed by the key on the remote you want to use for it (since version 2.4 you may have to press twice for added reliability).\n\nUsage: In order to jump to a track, enter the number of it on the remote and wait for Key Timeout or press Play.\n\nA different playlist will be loaded from the directory specified in plugin.ini if you enter its number and press the playlist button. You may also press <load playlist> and then <next track> or <prev track> to load the next or previous playlist.\nIf no file called <number>.m3u is found, the plug-in will try to load the playlist in the <number>th line of a text file called playlist.lst in the playlistdir (if any).\n\n\"Key speech\", when enabled, plays .wav files from your winamp dir when a key is pressed. Sample .wav files are provided.\n\n Infrared on/off allows you to temporarily stop the plugin from listening to your remote (it only listens to the <infrared on/off> button while off).","Help",MB_OK);
					break;
			case IDC_PLSTDIR:
					ShowBrowseDialog (hwndDlg, "Choose location for playlists 1.m3u to 9999.m3u",playlistdir);
					break;
			case IDC_LIST1:
					if (HIWORD(wParam)!=LBN_DBLCLK) break;
					// fallthrough.
			case IDC_CHANGEFILE:
				{
					OPENFILENAME x;
					char filename[FILENAME_MAX];
					char *filter="Wave files\0*.WAV\0\0";
					int selection;
					memset(&x,0,sizeof(x));
					x.lStructSize=sizeof(OPENFILENAME);
					x.hwndOwner=hwndDlg;
					x.lpstrFilter=filter;
					x.nMaxFile=FILENAME_MAX;
					selection=SendMessage(GetDlgItem(hwndDlg,IDC_LIST1),LB_GETCURSEL,(WPARAM)0,0);
					strcpy(filename,KeySpeechFiles[selection]);
					x.lpstrFile=filename;
					x.Flags=OFN_HIDEREADONLY|OFN_LONGNAMES;
					if (GetOpenFileName(&x))
						strcpy(KeySpeechFiles[selection],x.lpstrFile);
				}	
					break;
			default:
				if (LOWORD(wParam)<IDC_PLAY || LOWORD(wParam)>IDC_PLAY+NUM_KEYS)
					break;
				if (comPort==INVALID_HANDLE_VALUE)
					MessageBox(plugin.hwndParent,"IR-device not yet initialized.\n Make sure you set the COM-port correct.\n After that, press Apply to try initialization again.\n\nOnce initialized correctly you can setup your keys.","Error",MB_ICONEXCLAMATION|MB_OK);
				else
					if (DialogBox(plugin.hDllInstance,MAKEINTRESOURCE(IDD_NEXTKEY),plugin.hwndParent,NextKeyProc)==1)
					{
						int x;
						if (lastkey.a||lastkey.b) 
							for (x=0;x<NUM_KEYS;x++)
								if ((newkeys[x].a==lastkey.a)&&(newkeys[x].b==lastkey.b)&&(x!=LOWORD(wParam)-IDC_PLAY))
								{
									char xx[255]; 
									sprintf(xx,"Button pressed already in use by \'%s\' command.\n", KeyNames[x]); 
									MessageBox(hwndDlg, xx,"",MB_OK);
									break;
								}
						newkeys[LOWORD(wParam)-IDC_PLAY]=lastkey;
						if (DebugEnabled)
							{char xx[255]; sprintf(xx,"Learned %d %d (%d,%d)\n", wParam,wParam-IDC_PLAY,lastkey.a,lastkey.b); MessageBox(hwndDlg, xx,"",MB_OK);}
					}
					
				break;
			case IDC_APPLY:
			case IDOK:	
				{
				int x;
					int newcomportnr=SendDlgItemMessage(hwndDlg,IDC_COMPORT,CB_GETCURSEL,0,0);
					if (newcomportnr!=comportnr)
					{
						comportnr=newcomportnr;
						closecomport();
					}
					TimeoutOption=SendDlgItemMessage(hwndDlg,IDC_TIMEOUT,CB_GETCURSEL,0,0);
					PluginEnabled = IsDlgButtonChecked(hwndDlg,IDC_ENABLE);
					DebugEnabled = IsDlgButtonChecked(hwndDlg,IDC_DEBUG);
					KeyBeepEnabled = IsDlgButtonChecked(hwndDlg,IDC_KEYBEEP);
					KeySpeechEnabled = IsDlgButtonChecked(hwndDlg,IDC_KEYSPEECH);
					equalizer_controlEnabled = IsDlgButtonChecked(hwndDlg,IDC_EQUALIZER);
					if (PluginEnabled && (comPort==INVALID_HANDLE_VALUE))
					{
						opencomport();
					}
					for (x=0;x<NUM_KEYS;x++)
						KeyCodes[x]=newkeys[x];
					config_write();						// Fix 19990627, some people used to loose settings.
				}
			case IDCANCEL:
				if (LOWORD(wParam) != IDC_APPLY) EndDialog(hwndDlg,0);
			}
		case WM_NOTIFY:
				switch (LOWORD(wParam))
				case IDC_KEYTAB:
					{LPNMHDR lpnmhdr=(LPNMHDR) lParam; 
					if (lpnmhdr->code==TCN_SELCHANGE)
						show_tabpage(hwndDlg,TabCtrl_GetCurSel(lpnmhdr->hwndFrom));
					} break;
				default:break;
	}
	return FALSE;
}

BOOL CALLBACK NextKeyProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	static int first;
	switch (uMsg)
	{
		case WM_INITDIALOG:
			waitingHwnd=hwndDlg;
			first=0;
			ConfigWaitForKey=1;        /* Tells background thread to post key that is pressed next. */
			break;
		case WM_COMMAND:
			switch (LOWORD(wParam)) 
			{
				case IDCANCEL:
					ConfigWaitForKey=0;
					EndDialog(hwndDlg,0);
				case IDOK: /* Delete current key */
					lastkey.a=lastkey.b=0;
					ConfigWaitForKey=0;
					EndDialog(hwndDlg,1);
			}
			break;
		case WM_USER+2510:
			lastkey.a=wParam;
			lastkey.b=lParam;
			if (!first)
			{
				first=1;
				break;
			}	
			ConfigWaitForKey=0;
			EndDialog(hwndDlg,1);
			break;
	}
	return FALSE;
}

void config_read()
{
	char ini_file[MAX_PATH], *p;
	int x;
	GetModuleFileName(plugin.hDllInstance,ini_file,sizeof(ini_file));
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	strcat(ini_file,"plugin.ini");

	PluginEnabled = GetPrivateProfileInt(szAppName,"Enabled",PluginEnabled,ini_file);
	DebugEnabled = GetPrivateProfileInt(szAppName,"Debug",DebugEnabled,ini_file);
	KeyBeepEnabled = GetPrivateProfileInt(szAppName,"KeyBeep",KeyBeepEnabled,ini_file);
	KeySpeechEnabled = GetPrivateProfileInt(szAppName,"KeySpeech",KeySpeechEnabled,ini_file);
	comportnr = GetPrivateProfileInt(szAppName,"comportnr",comportnr,ini_file);
	filternoise= GetPrivateProfileInt(szAppName,"Filter",filternoise,ini_file);
	volumesteps= GetPrivateProfileInt(szAppName,"VolumeSteps",volumesteps,ini_file);
	presetvolume= GetPrivateProfileInt(szAppName,"PresetVolume",presetvolume,ini_file);
	TimeoutOption = GetPrivateProfileInt(szAppName,"Timeout",TimeoutOption,ini_file);
	equalizer_controlEnabled = GetPrivateProfileInt(szAppName,"ControlEqualizer",equalizer_controlEnabled,ini_file);
	GetPrivateProfileString(szAppName,"playlistdir","c:\\program files\\winamp",playlistdir,sizeof(playlistdir),ini_file);
	for (x = 0; x < 3; x ++)
	{
		char str[128];
		wsprintf(str,"ExtCmd_%d",x+1);
		GetPrivateProfileString(szAppName,str,"",extcmds[x],FILENAME_MAX,ini_file);
		wsprintf(str,"ExtArg_%d",x+1);
		GetPrivateProfileString(szAppName,str,"",extargs[x],FILENAME_MAX,ini_file);
	}
	for (x = 0; x < NUM_KEYS; x ++)
	{
		char str[128];
		wsprintf(str,"Key_%d",x);
		KeyCodes[x].a = GetPrivateProfileInt(szAppName,str,KeyCodes[x].a,ini_file);
		wsprintf(str,"Key_%db",x);
		KeyCodes[x].b = GetPrivateProfileInt(szAppName,str,KeyCodes[x].b,ini_file);
		wsprintf(str,"KeySpeechFile_%d",x);
		GetPrivateProfileString(szAppName,str,"",KeySpeechFiles[x],FILENAME_MAX,ini_file);
	}
}

void config_write()
{
	char ini_file[MAX_PATH], *p;
	char string[32],str[128];
	int x;
	GetModuleFileName(plugin.hDllInstance,ini_file,sizeof(ini_file));
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	strcat(ini_file,"plugin.ini");

	wsprintf(string,"%d",comportnr);       WritePrivateProfileString(szAppName,"comportnr",string,ini_file);
	wsprintf(string,"%d",TimeoutOption);   WritePrivateProfileString(szAppName,"Timeout",string,ini_file);
	wsprintf(string,"%d",PluginEnabled);   WritePrivateProfileString(szAppName,"Enabled",string,ini_file);
	wsprintf(string,"%d",DebugEnabled);	   WritePrivateProfileString(szAppName,"Debug",string,ini_file);
	wsprintf(string,"%d",KeyBeepEnabled);  WritePrivateProfileString(szAppName,"KeyBeep",string,ini_file);
	wsprintf(string,"%d",KeySpeechEnabled);WritePrivateProfileString(szAppName,"KeySpeech",string,ini_file);
	wsprintf(string,"%d",filternoise);     WritePrivateProfileString(szAppName,"Filter",string,ini_file);
	wsprintf(string,"%d",volumesteps);     WritePrivateProfileString(szAppName,"VolumeSteps",string,ini_file);
	wsprintf(string,"%d",presetvolume);		WritePrivateProfileString(szAppName,"PresetVolume",string,ini_file);
	wsprintf(string,"%d",equalizer_controlEnabled);	WritePrivateProfileString(szAppName,"ControlEqualizer",string,ini_file);
	
	WritePrivateProfileString(szAppName,"playlistdir",playlistdir,ini_file);
	/*
	for (x = 0; x < 3; x ++)
	{
		wsprintf(str,"ExtCmd_%d",x+1);
		WritePrivateProfileString(szAppName,str,extcmds[x],ini_file);
		wsprintf(str,"ExtArg_%d",x+1);
		WritePrivateProfileString(szAppName,str,extargs[x],ini_file);
	}
	*/

	for (x = 0; x < NUM_KEYS; x ++)
	{
		wsprintf(str,"Key_%d",x);
		wsprintf(string,"%d",KeyCodes[x].a);
		WritePrivateProfileString(szAppName,str,string,ini_file);
		wsprintf(str,"Key_%db",x);
		wsprintf(string,"%d",KeyCodes[x].b);
		WritePrivateProfileString(szAppName,str,string,ini_file);
		wsprintf(str,"KeySpeechFile_%d",x);
		WritePrivateProfileString(szAppName,str,KeySpeechFiles[x],ini_file);
	}
}

static void WriteData(HANDLE port,BYTE data)
{
	DWORD write;
	int x;
    
	if (!WriteFile(port,&data,1,&write,&Wov)) {
		x=GetLastError();
		if (x==ERROR_IO_PENDING) {
			while (!GetOverlappedResult(port,&Wov,&write,TRUE)) // wait until write completes!
			{
               if(GetLastError() != ERROR_IO_INCOMPLETE) // "incomplete" is normal result if not finished
               {	// an error occurred, try to recover
		   		   MessageBox(plugin.hwndParent,"Something went wrong when calling Windows to write to comport.","Message",MB_ICONEXCLAMATION|MB_OK);
				   break;
               }
			}
		}
		else {
			MessageBox(plugin.hwndParent,"Something went wrong when calling Windows to write to comport.","Message",MB_ICONEXCLAMATION|MB_OK);
//			CancelIo(port);
		}
	}

#ifdef _buggy_
	CloseHandle(ov.hEvent);
	ov.hEvent=INVALID_HANDLE_VALUE;
#endif
	Sleep(10); // let's give the microcontrol some processing time...
}

OVERLAPPED Rov,Wov;

static BOOL ReadData(HANDLE port,LPBYTE buffer,DWORD size,BOOL blocking)
{
	DWORD read = 0;
	int x;

	if (ReadFile(port,buffer,size,&read,&Rov))
	{
		if (read!=size)
		{
			char xx[100];
			wsprintf(xx,"Size mismatch %d %d",buffer[0],buffer[1]);
			MessageBox(plugin.hwndParent,xx,"Error",MB_ICONEXCLAMATION|MB_OK);
		}
		return (read == size);
	}
	else
	{
		switch (x=GetLastError())
		{
		case ERROR_IO_PENDING:
			if (blocking)
			{
				while (!GetOverlappedResult(port,&Rov,&read,TRUE)) // wait until read completes!
				{
					if(GetLastError() != ERROR_IO_INCOMPLETE)	// "incomplete" is normal result if not finished
					{
						MessageBox(plugin.hwndParent,"Something went wrong when calling Windows to read from comport.","Message",MB_ICONEXCLAMATION|MB_OK);
						break;	// an error occurred, try to recover
					}
				}
				return (read == size);
			}
			else 
			{
//				CancelIo(comPort);
				return FALSE;
			}

		default:
//			CancelIo(comPort);
			return FALSE;
		}
	}
}

static void PowerOff(HANDLE port)
{
	EscapeCommFunction(port, CLRDTR);
	EscapeCommFunction(port, CLRRTS);
}

static void PowerOn(HANDLE port)
{
	EscapeCommFunction(port, SETDTR);
	EscapeCommFunction(port, SETRTS);
}

void LoadPlaylist(unsigned int Number)
{
	char Playlist[256],Str1[256];
	int Result;
	FILE *File1;

	wsprintf(Playlist,"%s\\%i.m3u",playlistdir,Number); //At first, try to open x.m3u from playlistdir
	if(!(File1=fopen(Playlist,"rt")))
	{	//Unsuccessful: Try to open m3u from x.th line in playlist.lst
		wsprintf(Str1,"%s\\playlist.lst",playlistdir);
		if(!(File1=fopen(Str1,"rt"))) return; //No playlist.lst found
		while(Result=fgets(Playlist,256,File1) && Number>1) Number--;
		fclose(File1); if(Result) return; //x.th line not found
		if(Playlist[strlen(Playlist)-1]=='\n') Playlist[strlen(Playlist)-1]='\0'; //Delete last LFs
	}
	else fclose(File1);

	SendMessage(plugin.hwndParent,WM_WA_IPC,0,IPC_DELETE);
	{COPYDATASTRUCT cds;
		cds.dwData = IPC_PLAYFILE;
		cds.lpData = (void *) Playlist;
		cds.cbData = strlen((char *) cds.lpData)+1; // include space for null char
		SendMessage(plugin.hwndParent,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);
	}

	SendMessage(plugin.hwndParent,WM_WA_IPC,0, IPC_STARTPLAY);
}

void JumpToTrack(unsigned int Number)
{
	PostMessage(plugin.hwndParent,WM_COMMAND,WINAMP_BUTTON4,0);
	Number--;
	PostMessage(plugin.hwndParent,WM_WA_IPC,Number,IPC_SETPLAYLISTPOS);
	PostMessage(plugin.hwndParent,WM_COMMAND,WINAMP_BUTTON2,0);
}

int __stdcall WorkerThreadFunc(LPVOID Param)
{
	keyType keyCode={0,0};
	static int EnteredNumber=0;
	static double lasttime,curtime;
	static keyType lastkeyCode={0,0};
	static clock_t Alasttime,time,Afirsttime;
	static int maybegarbage=0;
	static DWORD read;
	static DataRead,ReadRequested=0;
	int x,CodeFound,eq_showing;
	static int eq_currentslider=0;
	double duration;
	for (;;)
	{
		// Get data from UIR
		if(!ReadRequested)
		{
			DataRead=0;  //Data from serial port was not already requested: Do it now. ;-)
			if(ReadFile(comPort,(unsigned char*)&keyCode,6,&read,&Rov))
			{
				if(read!=6)
					PurgeComm(comPort,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
//					MessageBox(plugin.hwndParent,"Size mismatch.","Error",MB_ICONEXCLAMATION|MB_OK);
				else 
					DataRead=(read==6); //Data requested and read. Very well.
			}
			else if(GetLastError()==ERROR_IO_PENDING) 
				ReadRequested=1; //Data requested, but not ready. We'll have to wait.
		}
		else if(GetOverlappedResult(comPort,&Rov,&read,(TimeoutOption>0)?FALSE:TRUE)) {
			ReadRequested=0;
			DataRead=(read==6);
		} //Hey, data is finally ready!
		
		// Process data if any
		if(DataRead)
		{
			if (keyCode.a==0 && keyCode.b==0)  //Null codes are not valid and should not be sent by the UIR.
			{
				if(DebugEnabled)
					MessageBox(plugin.hwndParent,"Received invalid null code.","UIR debug info",MB_ICONEXCLAMATION|MB_OK);
				continue;
			}
			if (filternoise&0x2)  // RC5 First bit toggling filter.
				keyCode.a|=0x40;
			if (ConfigWaitForKey) //Configuration dialog is waiting for keycode
			{
				PostMessage(waitingHwnd,WM_USER+2510,keyCode.a,keyCode.b);
				continue;
			}

			CodeFound=0;
			if (PluginEnabled) //Configuation dialog is not waiting: normal operation
			{
				for (x=0;x<NUM_KEYS;x++)
					if (KeyCodes[x].a==keyCode.a && KeyCodes[x].b==keyCode.b) 
					{
						time=clock();
						duration = ((double)(time - Alasttime))/ CLOCKS_PER_SEC;
						Alasttime=time;
						if ((keyCode.a==lastkeyCode.a) && (keyCode.b==lastkeyCode.b)) {
							if (duration>0.5) {
								maybegarbage=1;
								if (filternoise&0x1) // Ambient light filtering.
									break;
							}
							if (maybegarbage) {
								Afirsttime=time;
							}
							else if (time<Afirsttime+0.8*CLOCKS_PER_SEC)
								break;
							else
								maybegarbage=0;
						} 
						else
							Afirsttime=time;

			   			maybegarbage=0;
						lastkeyCode=keyCode;

						CodeFound=1; //A key with the current code assigned to it was found
						if (KeyCommands[x]==IDC_REMOTE)
							irenabled=(!irenabled);

						// play the voice sample
						if (KeySpeechEnabled&&strlen(KeySpeechFiles[x]))
 							PlaySound(KeySpeechFiles[x],NULL,SND_ASYNC|SND_FILENAME|SND_NODEFAULT|SND_NOWAIT);

						eq_showing=equalizer_controlEnabled&&IsWindowVisible(FindWindow("Winamp EQ",NULL));

						if (!irenabled)
							break;

						if(DebugEnabled)
						{
							char str[256];
							wsprintf(str,"Executing command: %i\nIts keycode: %d,%d",x,keyCode.a,keyCode.b);
							MessageBox(plugin.hwndParent,str,"UIR debug info",MB_ICONEXCLAMATION|MB_OK);
						}

						if (KeyCommands[x]>=IDC_KEY0 && KeyCommands[x]<=IDC_KEY9) 
						{
							EnteredNumber*=10;
							EnteredNumber+=KeyCommands[x]-IDC_KEY0;
							if(KeyBeepEnabled) MessageBeep(0xFFFFFFFF); //Anyone got an idea how to get a louder beep with Win9x?
							lasttime=(double)clock()/CLOCKS_PER_SEC; //Trigger timeout
						}
						else
						if(KeyCommands[x]==WINAMP_VOLUMEUP || KeyCommands[x]==WINAMP_VOLUMEDOWN)
						{	
							int i;
							if (eq_showing)
							{
								int value=SendMessage(plugin.hwndParent,WM_WA_IPC,eq_currentslider,IPC_GETEQDATA);
								int ovalue;
								ovalue=value;
								value+=(KeyCommands[x]==WINAMP_VOLUMEUP?-1:1);
								if(value<0) value=0;
								if(value>63) value=63;
								SendMessage(plugin.hwndParent,WM_WA_IPC,value,IPC_SETEQDATA);
								{
									// Update code!
									double d;
									int x,db;
									HWND hEQ=FindWindow("Winamp EQ",NULL);
									RECT rc;

									// Is WinAmp double size or not?
									GetClientRect(hEQ,&rc);
									db=(rc.right-rc.left>300)?2:1;
									
									x=(eq_currentslider==10?27:84+eq_currentslider*18)*db;				
									d=52*db/63.0;

									// simulate mouse action on the right spot
									SendMessage(hEQ,WM_LBUTTONDOWN,1, (int)(44*db+ovalue*d)<<16 | x);
									SendMessage(hEQ,WM_LBUTTONUP,0, (int)(44*db+value*d)<<16 | x);
								}
							}
							else
								for (i=0;i<volumesteps;i++)
									PostMessage(plugin.hwndParent,WM_COMMAND,KeyCommands[x],0);							
						}
						else
						if(eq_showing&&(KeyCommands[x]==WINAMP_BUTTON1 || KeyCommands[x]==WINAMP_BUTTON5))
						{	
							if (KeyCommands[x]==WINAMP_BUTTON1)
									eq_currentslider--;
							else
									eq_currentslider++;
							if(eq_currentslider>10)
								eq_currentslider=0;
							if(eq_currentslider<0)
								eq_currentslider=10;
						}
						else
						if(KeyCommands[x]==IDC_PLAYLIST)
						{	
							if(EnteredNumber>0)
							{
								LoadPlaylist(playlistnumber=EnteredNumber); EnteredNumber=0;
							}
							else 
								changingplaylist=1;
						}
						else
						if(KeyCommands[x]==IPC_SETVOLUME)
						{	
									SendMessage(plugin.hwndParent,WM_WA_IPC,presetvolume,IPC_SETVOLUME);
						}
						else
						if(KeyCommands[x]>=IDC_EXTCMD1 && KeyCommands[x]<=IDC_EXTCMD3)
						{	
							ShellExecute(NULL,"open",extcmds[KeyCommands[x]-IDC_EXTCMD1],extargs[KeyCommands[x]-IDC_EXTCMD1],NULL,SW_SHOWNA );
						}
						else
						if (KeyCommands[x]==IDC_NEXTPLAYLIST)
						{
								LoadPlaylist(++playlistnumber);
								changingplaylist=0;
						}
						else
						if (KeyCommands[x]==IDC_PREVPLAYLIST)
						{
								if (playlistnumber>1) playlistnumber--;
								LoadPlaylist(playlistnumber); 
								changingplaylist=0;
						}
						else
						if((KeyCommands[x]==WINAMP_BUTTON2)&&(EnteredNumber>0))
						{	
							JumpToTrack(EnteredNumber); EnteredNumber=0;
						}
						else
						if (changingplaylist&&((KeyCommands[x]==WINAMP_BUTTON1)||(KeyCommands[x]==WINAMP_BUTTON5)))
						{
							if (KeyCommands[x]==WINAMP_BUTTON1)
								playlistnumber--;
							else
								playlistnumber++;

							if (playlistnumber<=0)
								playlistnumber=1;
							LoadPlaylist(playlistnumber); 
							changingplaylist=0;
						}
						else
						{
							EnteredNumber=0;
							if (KeyCommands[x]==IDC_SUSPEND)
							{
								EnteredNumber=0;
	//							RequestDeviceWakeup(comPort);
								SetSystemPowerState( 1,0);
							}
							else if (KeyCommands[x]==IDC_SHUTDOWN)
							{
								if (!ExitWindowsEx(EWX_SHUTDOWN , 0))
									MessageBox(plugin.hwndParent,"Could not perform shutdown and/or poweroff","Message",MB_ICONEXCLAMATION|MB_OK);
							}
							else
							{
								PostMessage(plugin.hwndParent,WM_COMMAND,KeyCommands[x],0);
							}
						}
						break; //Command executed: Quit searching for other keys
					} //for

				if(DebugEnabled&&!CodeFound) //A code not assigned to a command has been received
				{
					char str[256];
					wsprintf(str,"Invalid keycode received: %d,%d",keyCode.a,keyCode.b);
					MessageBox(plugin.hwndParent,str,"UIR debug info",MB_ICONEXCLAMATION|MB_OK);
				}
			}
		};

		Sleep(50); //Just in order to save processor time.

		//Now check for timeout and resulting actions
		curtime=(double)clock()/CLOCKS_PER_SEC;
		if((TimeoutOption>0)&&(((curtime-lasttime)>TimeoutValues[TimeoutOption])&&(EnteredNumber>0)))
		{
			if (changingplaylist)
			{
				LoadPlaylist(playlistnumber=EnteredNumber);
				changingplaylist=0;
			}
			else
				JumpToTrack(EnteredNumber);
			EnteredNumber=0;
		}
	}
	return TRUE;
}


static BOOL
ShowBrowseDialog (HWND hDlg, char*text,char *ret)
{
	// Set up a browse info structure
	BROWSEINFO		bi;
	
	// Set up a buffer
    LPSTR			lpBuffer;

	// Allocate a pointer to an IMalloc interface
	LPMALLOC	g_pMalloc;
	
	// PIDL for Desktop folder
    LPITEMIDLIST pidlDesktop;
	
	// PIDL selected by user 
    LPITEMIDLIST pidlBrowse;    

	// Get the address of our task allocator's IMalloc interface
	SHGetMalloc(&g_pMalloc);
 
    // Allocate a buffer to receive browse information. 
    if ((lpBuffer = (LPSTR) g_pMalloc->lpVtbl->Alloc( 
            g_pMalloc, MAX_PATH)) == NULL) 
        return FALSE; 
 
    // Get the PIDL for the Desktop folder
    if (!SUCCEEDED(SHGetSpecialFolderLocation( 
            hDlg, CSIDL_DESKTOP, &pidlDesktop))) { 
        g_pMalloc->lpVtbl->Free(g_pMalloc, lpBuffer); 
        return FALSE; 
    } 
 
    // Fill in the BROWSEINFO structure. 
    bi.hwndOwner = hDlg; 
    bi.pidlRoot = pidlDesktop; 
    bi.pszDisplayName = lpBuffer; 
    bi.lpszTitle = TEXT(text);
    bi.ulFlags = BIF_RETURNONLYFSDIRS;
    bi.lpfn = NULL; 
    bi.lParam = 0; 
 
    // Browse for a folder and return its PIDL. 
    pidlBrowse = SHBrowseForFolder(&bi); 
    if (pidlBrowse != NULL) { 
    
		if (!SHGetPathFromIDList(pidlBrowse, lpBuffer)) 
			lpBuffer="";
        // Free the PIDL returned by SHBrowseForFolder. 
        g_pMalloc->lpVtbl->Free(g_pMalloc, pidlBrowse); 
		if (strlen(lpBuffer))
			strcpy(ret,lpBuffer);
    } 
 
    // Clean up. 
    g_pMalloc->lpVtbl->Free(g_pMalloc, pidlDesktop); 
    g_pMalloc->lpVtbl->Free(g_pMalloc, lpBuffer); 
	return TRUE;
}



