//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDS_FIRST_TAB                   1
#define IDS_SECOND_TAB                  2
#define IDC_APPLY                       3
#define IDS_THIRD_TAB                   3
#define IDS_FOURTH_TAB                  4
#define IDC_HELPTEXT                    4
#define NUM_TABS                        4
#define IDD_DIALOG1                     101
#define IDD_NEXTKEY                     103
#define IDC_ENABLE                      1000
#define IDC_SENS                        1007
#define IDC_DEBUG                       1006
#define IDC_EQUALIZER                   1001
#define IDC_UP                          1002
#define IDC_KEYBEEP                     1002
#define IDC_IRTYPE                      1003
#define IDC_KEYSPEECH                   1003
#define IDC_DOWN                        1004
#define IDC_COMPORT                     1004
#define IDC_TIMEOUT                     1005
#define IDC_PLAY                        1011
#define IDC_PAUSE                       1012
#define IDC_NEXTTRACK                   1013
#define IDC_PREVTRACK                   1014
#define IDC_FWD10                       1015
#define IDC_BACK10                      1016
#define IDC_VOLUMEUP                    1017
#define IDC_VOLUMEDOWN                  1018
#define IDC_FORWARD5                    1019
#define IDC_REWIND5                     1020
#define IDC_STOP                        1021
#define IDC_KEY0                        1022
#define IDC_KEY1                        1023
#define IDC_KEY2                        1024
#define IDC_KEY3                        1025
#define IDC_KEY4                        1026
#define IDC_KEY5                        1027
#define IDC_KEY6                        1028
#define IDC_KEY7                        1029
#define IDC_KEY8                        1030
#define IDC_KEY9                        1031
#define IDC_SUSPEND                     1032
#define IDC_SHUFFLE                     1033
#define IDC_SHUTDOWN                    1034
#define IDC_PLAYLIST                    1035
#define IDC_REPEAT                      1036
#define IDC_CLOSEWINAMP                 1037
#define IDC_VISUALPLUGIN                1038
#define IDC_REMOTE                      1039
#define IDC_FADEOUT                     1040
#define IDC_PREVPLAYLIST                1041
#define IDC_NEXTPLAYLIST                1042
#define IDC_TOGGLETIME                  1043
#define IDC_OPTIONSEQ                   1044
#define IDC_EXTCMD1                     1045
#define IDC_EXTCMD2                     1046
#define IDC_EXTCMD3                     1047
#define IDC_PRESETVOL                   1048
#define IDC_KEYTAB                      1100
#define IDC_PLSTDIR                     1101
#define IDC_LIST1                       1102
#define IDC_CHANGEFILE                  1103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
