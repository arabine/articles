/****************************************************************************
** OggEditorDialog meta object code from reading C++ file 'oggeditordialog.h'
**
** Created: Thu Nov 13 12:58:27 2003
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.2.1   edited Aug 20 15:04 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../oggeditordialog.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *OggEditorDialog::className() const
{
    return "OggEditorDialog";
}

QMetaObject *OggEditorDialog::metaObj = 0;
static QMetaObjectCleanUp cleanUp_OggEditorDialog( "OggEditorDialog", &OggEditorDialog::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString OggEditorDialog::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "OggEditorDialog", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString OggEditorDialog::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "OggEditorDialog", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* OggEditorDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = MainForm::staticMetaObject();
    static const QUMethod slot_0 = {"openOggFile", 0, 0 };
    static const QUMethod slot_1 = {"saveOggFile", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "openOggFile()", &slot_0, QMetaData::Public },
	{ "saveOggFile()", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"OggEditorDialog", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_OggEditorDialog.setMetaObject( metaObj );
    return metaObj;
}

void* OggEditorDialog::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "OggEditorDialog" ) )
	return this;
    return MainForm::qt_cast( clname );
}

bool OggEditorDialog::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: openOggFile(); break;
    case 1: saveOggFile(); break;
    default:
	return MainForm::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool OggEditorDialog::qt_emit( int _id, QUObject* _o )
{
    return MainForm::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool OggEditorDialog::qt_property( int id, int f, QVariant* v)
{
    return MainForm::qt_property( id, f, v);
}

bool OggEditorDialog::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
