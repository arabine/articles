/*=============================================================================
 * OggEditor - OggFile.cpp
 *=============================================================================
 * Librairie de lecture/�criture d'informations contenues dans un fichier Ogg
 *=============================================================================
 * (c) Anthony RABINE - 2003
 * arabine@programmationworld.com
 * http://www.programmationworld.com
 * Environnement : VC++ 6.0 sous Windows, g++ sous Linux
 *  
 * La majorit� du code source de ce fichier a �t� pris dans l'utilitaire 
 * "vorbiscomment" disponible sur le site http://www.xiph.org/ogg/vorbis/
 * (vorbis-tools)
 *
 * Historique :
 * 
 * 10/2003 : premi�re version
 *
 *=============================================================================
 */

#include "OggFile.h"

/*****************************************************************************/
/**
 * Allez on se retrousse les manches et on construit !
 */
OggFile::OggFile()
{
	fileOpened = false;
	packet_continued = false;
	read_ended = false;

	// allocation par d�faut des variables dynamiques
	vendor_string = new char[1];
	user_comment_list_length = 1;
	comment[0] = new char[1];
	stream = new unsigned char[1];
	file_name = new char[1];

	// initialisation des variables de contr�le
	curr_pos = NOTHING;
	prec_pos = NOTHING;
	vorbis_headers = 0;

}
/*****************************************************************************/
/**
 * Destructeur, on d�truit... pour mieux reconstruire !!
 */
OggFile::~OggFile()
{
	delete[] vendor_string;
	delete[] file_name;
	
	for(unsigned int i=0;i<user_comment_list_length;i++)
		delete[] comment[i];
}
/*****************************************************************************/
/**
 * Lit un fichier Ogg et lance le d�codage des donn�es
 * Entr�e : chemin du fichier Ogg
 * Sortie : 0 si tout s'est bien pass�
 *			sinon un code d'erreur (voir le fichier error.h)
 */
int OggFile::readOggFile(const char *fileName)
{
	unsigned char *p_stream;	// pointeur vers le fichier
	unsigned int page_offset;	// pointe sur le premier octet de la page � d�coder
	int ret;

	fileOpened = false;			// r�initialisation d'indicateur de validit�
	
	ret = openOggFile(fileName);
	if(ret)
		return ret;

	delete[] file_name;
	file_name = new char[strlen(fileName)+1];
	strcpy(file_name, fileName);

	// Maintenant que le fichier est en m�moire, on va lancer la proc�dure de d�codage
	p_stream = stream;			// on utilise un autre pointeur pour garder la position initiale
	page_offset = 0;			// on commence au d�but du fichier
	read_ended = false;
	packet_continued = false;
	new_comment = false;

	// On boucle tant qu'on n'a pas lu les deux en-t�tes vorbis
	// et qu'on est pas � la derni�re page
	do
	{
		ret = decodeOggPage(p_stream, &page_offset);
		if(ret)
			return ret;			// on quitte � la moindre erreur

	}while(curr_pos != LAST_PAGE && read_ended == false);

	if(vorbis_headers == 2)
	{
		fileOpened = true;		// le fichier est valide et ses caract�ristiques disponibles
		return 0;
	}
	else
		return OGG_FORMAT_ERROR;
	
}
/*****************************************************************************/
/**
 * Charge un fichier en m�moire
 * Entr�e : chemin du fichier
 * Sortie : 0 si tout s'est bien pass�
 *			sinon un code d'erreur (voir le fichier error.h)
 */
int OggFile::openOggFile(const char *fileName)
{
	FILE *fp;
	int ret;

	fp = fopen(fileName, "rb");
	tailleFichier = filesize(fp);

	delete[] stream;
	stream = new unsigned char[tailleFichier];
	if(stream == NULL)
	{
		fclose(fp);
		return FILE_MEM_ALLOC_ERR;
	}

	ret = fread(stream, sizeof(unsigned char), tailleFichier, fp);
	if(ret != tailleFichier)
	{
		fclose(fp);
		return FILE_READ_ERROR;
	}

	fclose(fp);
	return 0;

}
/*****************************************************************************/
/**
 * Retourne la taille du fichier en octets
 */
long int OggFile::filesize(FILE *stream)
{
	long int curpos,length;

	curpos = ftell(stream); /* garder la position courante */
	fseek(stream, 0L, SEEK_END);
	length = ftell(stream);
	fseek (stream, curpos, SEEK_SET); /* restituer la position */
	
	return length;
}
/*****************************************************************************/
/**
 * D�code l'en-t�te d'une page et le packet Vorbis
 * Entr�e : 
 *			data	= pointeur vers le fichier en m�moire
 *			offset	= offset de saut de page, mis � jour dans cette m�thode
 * Sortie :
 *			0 si tout s'est bien pass�
 *			sinon un code d'erreur (voir le fichier error.h)
 */
int OggFile::decodeOggPage(unsigned char *data, unsigned int *offset)
{
	char buff[256];
	unsigned int i;
	int ret;
	unsigned int temp;			

	unsigned char *stream = data + *offset; /* d�part de la nouvelle page */
	unsigned char header_type_flag;
	unsigned long page_checksum;
	unsigned int page_number;
	unsigned long page_size;
	unsigned char *page_table;
	unsigned long calculated_checksum;
	unsigned long granule_position;

	/* on lit le capture_pattern */
	memcpy(buff, stream, 4);
	buff[4]='\0';
	if(strcmp(buff, "OggS"))
		return PAGE_NOT_OGG;

	/* on lit stream_structure_version */
	if(stream[4]!=0x00)
		return PAGE_UNKNOWN_VERSION;

	/* on lit header_type_flag
	bitflags:
			0x01: unset = fresh packet
	              set = continued packet
			0x02: unset = not first page of logical bitstream
                  set = first page of logical bitstream (bos)
			0x04: unset = not last page of logical bitstream
                  set = last page of logical bitstream (eos
	
	*/
	
	header_type_flag = stream[5];
	if((header_type_flag & 0x01) == 0x01)
	{
	
	}
	if((header_type_flag & 0x02) == 0x02)
	{
		/* On d�tecte ici s'il y a une nouvelle page */
		if(curr_pos == NOTHING && prec_pos == NOTHING)
		{
			curr_pos = FIRST_PAGE;
		
		}
		else
			return PAGE_BAD_HEADER_TYPE;				
	
	}
	if((header_type_flag & 0x04) == 0x04)
	{
		curr_pos = LAST_PAGE;
	}


	/* Calcul de absolute granule position (bit 6 to 13)
	   limitation : on le calcule avec seulement 4 octets ... on ne s'en sert pas de toutes fa�ons !
	*/
	granule_position = stream[6]+stream[7]*256+stream[8]*65536+stream[9]*16777216;

	/* serial number */
	page_serial_number = stream[14]+stream[15]*256+stream[16]*65536+stream[17]*16777216;

	/* num�ro de la page (commence � 0) */
	page_number = stream[18]+stream[19]*256+stream[20]*65536+stream[21]*16777216;

	/* CRC Checksum */
	page_checksum = stream[22]+stream[23]*256+stream[24]*65536+stream[25]*16777216;
	
	/* nombre de segments dans cette page (maxi=256) */
	page_segments = stream[26];
	if(page_segments>256)
		return 10;

	/* lecture des "lacing values" */
	i = page_segments;
	temp = 0;
	if(i>0)
	{
		do
		{
			lacing_table[i-1] = stream[26+i];
			temp += stream[26+i]; /* addition de la taille totale, preparation pour le calcul de la taille de la 
									page (voir ci-dessous) */
		}
		while(--i);
	}

	/* On pr�pare une table avec toute la page, mais avec 0000 � la place du num�ro de s�rie */
	
	/* Taille de la page */
	page_size = 27 + page_segments + temp;

	/* on alloue la m�moire et on copie la page dedans */
	page_table = new unsigned char[page_size];
	if(page_table == NULL)
		return PAGE_MEM_ALLOC_ERROR;

	/* update offset */
	*offset = *offset + page_size;

	for(i=0;i<page_size;i++)
		page_table[i] = stream[i];

	/* on remplace le checksum par des z�ros */
	page_table[22] = 0;
	page_table[23] = 0;
	page_table[24] = 0;
	page_table[25] = 0;

	/* enfin, on calcule le checksum */
	calculated_checksum = crc_normal(page_table, page_size);

	delete[] page_table;

	if(calculated_checksum != page_checksum)
		return PAGE_CHECKSUM_ERROR;

	/* on pointe sur le packet et on le d�code ... */
	ret = decodeOggPacket(stream + 27 + page_segments);
	if(ret)
		return ret;

	return 0;
}
/*****************************************************************************/
/**
 * D�code le packet d'une page, constitu�e de segments cons�cutifs
 * Entr�e : 
 *			data			= pointeur vers le fichier en m�moire
 *			lacing_table	= taille des segments du packet
 *			segments		= nombre de segments
 * Sortie :
 *			0 si tout s'est bien pass�
 *			sinon un code d'erreur (voir le fichier error.h)
 */
int OggFile::decodeOggPacket(unsigned char *data)
{
	/*	On est au d�but d'un paquet, on d�code les segments*/
	unsigned int i, offset;
	int ret;

	for(i=0;i<page_segments;i++)
	{
		if(i==0)
			offset = 0;
		else
			offset = lacing_table[i-1];

		data = data + offset;
		ret = decodeVorbisSegment(data, lacing_table[i]);
		if(ret)
			return ret;
		if(read_ended == true)
		{
			pos_setup = i;	// on sauvegarde la position du setup
			return 0;
		}
	}

	return 0;
}
/*****************************************************************************/
/**
 * D�code un segment vorbis
 * Entr�e : 
 *			header	= pointeur sur le premier octet d'un segment
 *			size	= taille du segment courant
 * Sortie :
 *			0 si tout s'est bien pass�
 *			sinon un code d'erreur (voir le fichier error.h)
 */
int OggFile::decodeVorbisSegment(unsigned char* header, unsigned int size)
{

	unsigned char buff[7];
	unsigned char *end_adr = header + size;
	int ret;


	if(vorbis_headers==0)			// on recherche l'en-t�te d'identification
	{
		memcpy(buff, header+1, 6);
		buff[6]='\0';
		if(!strcmp((char *)buff, "vorbis"))
		{
			if(header[0] == 0x01)
			{
				ret = decodeVorbisIdentHeader(header);
				if(ret)
					return ret;
				
				vorbis_headers = 1;		// on lit le prochain en-t�te vorbis
				header = header + 30;	// on avance le pointeur
			}
			else
				return VORBIS_HEADER_ERR;
		}
		else
			return VORBIS_HEADER_ERR;
	}
	
	if(header == end_adr)				// fin du segment ?
		return 0;

	if(vorbis_headers==1)			// on recherche l'en-t�te de commentaires
	{
		if(packet_continued == true)
		{
			ret = decodeVorbisCommentHeader(header, size);
			if(ret)
				return ret;
		}
		else
		{
			memcpy(buff, header+1, 6);
			buff[6]='\0';
			if(!strcmp((char *)buff, "vorbis"))
			{
				if(header[0] == 0x03)
				{
					ret = decodeVorbisCommentHeader(header, size);
					if(ret)
						return ret;
				}
				else
					return VORBIS_HEADER_ERR;
			}
		}
	}

	if(header == end_adr)				// fin du segment ?
		return 0;
	
	if(vorbis_headers==2)			// on recherche l'en-t�te de setup
	{
		memcpy(buff, header+1, 6);
		buff[6]='\0';
		if(!strcmp((char *)buff, "vorbis"))
		{
			if(header[0] == 0x05)
			{
				p_setup_header = header;
				read_ended = true;
			}
			else
				return VORBIS_HEADER_ERR;
		}

	}

	return 0;

}
/*****************************************************************************/
/**
 * D�code l'en-t�te Vorbis d'identification
 * Entr�e : 
 *			header	= pointeur vers le fichier en m�moire
 * Sortie :
 *			0 si tout s'est bien pass�
 *			sinon un code d'erreur (voir le fichier error.h)
 */
int OggFile::decodeVorbisIdentHeader(unsigned char* header)
{
	vorbis_version = header[7]+header[8]*256+header[9]*65536+header[10]*16777216;
	audio_channels = header[11];
	audio_sample_rate = header[12]+header[13]*256+header[14]*65536+header[15]*16777216;
	bitrate_maximum = header[16]+header[17]*256+header[18]*65536+header[19]*16777216;
	bitrate_nominal = header[20]+header[21]*256+header[22]*65536+header[23]*16777216;
	bitrate_minimum = header[24]+header[25]*256+header[26]*65536+header[27]*16777216;
	blocksize_0 = 1<<(header[28] >> 4);
	blocksize_1 = 1<<(header[28] & 0x0F);
	framing_flag = header[29];

	if(framing_flag != 0x01)
		return VORBIS_IDENT_FRAM;	/* must be equal to 1 for the identification header */
	

	return 0;
}
/*****************************************************************************/
/**
 * D�code l'en-t�te Vorbis de commentaires
 * Entr�e : 
 *			header		= pointeur vers le premier octet en m�moire
 *			seg_size	= taille du segment o� l'on est
 * Sortie :
 *			0 si tout s'est bien pass�
 *			sinon un code d'erreur (voir le fichier error.h)
 */
int OggFile::decodeVorbisCommentHeader(unsigned char* &header, unsigned int seg_size)
{
	unsigned int i;
	unsigned int data_end = seg_size;
	unsigned char temp;

	char *buff;

	if(packet_continued == false)
	{
		// On d�salloue les anciens commentaires
		delete[] vendor_string;
		for(i=0;i<user_comment_list_length;i++)
			delete[] comment[i];

		vendor_length = header[7]+header[8]*256+header[9]*65536+header[10]*16777216;
		vendor_string = new char[vendor_length+1];
		if(vendor_string == NULL)
			return VORBIS_MEM_ALLOC_ERR;

		memcpy(vendor_string, header+11, vendor_length);
		vendor_string[vendor_length]='\0';
		
		header = header + 11 + vendor_length;	// update pointer
		user_comment_list_length = header[0]+header[1]*256+header[2]*65536+header[3]*16777216;
		header = header + 4;					// update pointer
		
		if(user_comment_list_length == 0)
			return 0;

		data_end = seg_size - 15 - vendor_length;	// taille restante du segment
		comment_index = 0;
		new_comment = true;
	}
	
	do
	{
		if(new_comment == true)
		{
			comment_size = header[0]+header[1]*256+header[2]*65536+header[3]*16777216; // taille du commentaire
			header = header + 4;
			
			comment[comment_index] = new char[comment_size+1];
			if(comment[comment_index] == NULL)
				return VORBIS_MEM_ALLOC_ERR;

			data_end = data_end - 4;
			data_left = comment_size;
			new_comment = false;
		}

		buff = &comment[comment_index][comment_size-data_left];
		
		if(data_left > data_end)
		{	
			memcpy(buff, header, data_end);

			header = header + data_end;
			data_left = data_left - data_end;
			packet_continued = true;
			new_comment = false;
			return 0;
		}
		else
		{
			memcpy(buff, header, data_left);
			comment[comment_index][comment_size] = '\0';

			header = header + data_left;
			data_end = data_end - data_left;
			comment_index++;
			new_comment = true;
			packet_continued = false;
		}

	}
	while(user_comment_list_length - comment_index != 0);

	temp = header[0];
	if((temp & 0x01) != 0x01)
		return VORBIS_COMMENT_FRAME;
	header++;
	packet_continued = false;
	vorbis_headers = 2;
	
	return 0;
}

/*****************************************************************************/
/**
 * Calcule le CRC d'un tableau pass� en param�tre
 */
unsigned long OggFile::crc_normal(unsigned char *blk_adr, unsigned long blk_len)
{
	unsigned long crc = INIT;
	while (blk_len--)
	   crc = crctable[((crc>>24) ^ *blk_adr++) & 0xFFL] ^ (crc << 8);
	return crc ^ XOROT;
}

//=============================================================================
// Fin du fichier OggFile.cpp
//=============================================================================
