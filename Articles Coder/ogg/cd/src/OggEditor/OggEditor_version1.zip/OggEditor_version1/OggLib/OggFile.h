/*=============================================================================
 * OggEditor - OggFile.h
 *=============================================================================
 * Librairie de lecture/�criture d'informations contenues dans un fichier Ogg
 *=============================================================================
 * (c) Anthony RABINE - 2003
 * arabine@programmationworld.com
 * http://www.programmationworld.com
 * Environnement : VC++ 6.0 sous Windows, g++ sous Linux
 *  
 * La majorit� du code source de ce fichier a �t� pris dans l'utilitaire 
 * "vorbiscomment" disponible sur le site http://www.xiph.org/ogg/vorbis/
 * (vorbis-tools)
 *
 * Historique :
 * 
 * 10/2003 : premi�re version
 *
 *=============================================================================
 */

#ifndef OGGFILE_H
#define OGGFILE_H

// Includes standards
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

// Includes locales
#include "error.h"

// pour contr�ler les pages successives
enum Position {NOTHING, NEW_PAGE, FIRST_PAGE, LAST_PAGE};

// Voir le RFC sur le format Ogg pour ces param�tres
#define INIT 0		// Pour le calcul duchecksum
#define XOROT 0		// Pour le calcul duchecksum

extern unsigned long  crctable[256];

/*****************************************************************************/
class OggFile
{

private:

	// informations g�n�rales sur le format Vorbis et Ogg
	unsigned int	vorbis_version;
	unsigned int	audio_channels;
	unsigned int	audio_sample_rate;
	signed int		bitrate_maximum;
	signed int		bitrate_nominal;
	signed int		bitrate_minimum;
	unsigned int	blocksize_0;
	unsigned int	blocksize_1;
	unsigned char	framing_flag;
	unsigned int	page_serial_number;	

	// Commentaires
	unsigned int	vendor_length;
	char			*vendor_string;
	unsigned int	user_comment_list_length;
	char			*comment[256];
	unsigned int	comment_sizes[256];

	// variables pour contr�ler la proc�dure de d�codage
	Position		curr_pos, prec_pos;		// pour les pages
	int				vorbis_headers;			// compte le nombre d'en-t�tes vorbis

	// sauvegardes des valeurs lors d'un passage de segments
	unsigned int	data_left;				// quantit� de donn�es restantes � lire dans le segment
	bool			packet_continued;		// mis � vrai si des donn�es sont � cheval entre plusieurs segments
	unsigned int	comment_index;			// commentaire courant
	unsigned		comment_size;			// taille du commentaire courant
	bool			read_ended;				// vrai d�s que la lecture des commentaires est termin�e
	bool			new_comment;

	// Informations sur le fichier Ogg
	bool			fileOpened;				// vrai si un fichier a �t� correctement charg�
	unsigned char	*stream;				// fichier Ogg en m�moire
	long int		tailleFichier;
	char			*file_name;				// nom et emplacement du fichier

	// Informations suppl�mentaires pour pr�parer l'�criture du fichier Ogg
	unsigned char	*file_out;				// buffer fichier de sortie
	unsigned char	*p_setup_header;		// adresse du d�but du header setup
	unsigned int	pos_setup;				// num�ro du segment o� se situe le setup
	unsigned char	lacing_table[256];		// lacing table courante
	unsigned int	page_segments;			// nombre de segments dans lacing table


	// m�thodes priv�es, utilis�es en interne de la classe
	unsigned long	crc_normal(unsigned char *blk_adr, unsigned long blk_len);
	int				openOggFile(const char *fileName);
	long int		filesize(FILE *stream);
	int				decodeOggPage(unsigned char *data, unsigned int *offset);
	int				decodeOggPacket(unsigned char *data);
	int				decodeVorbisSegment(unsigned char* header, unsigned int size);
	int				decodeVorbisIdentHeader(unsigned char* header);
	int				decodeVorbisCommentHeader(unsigned char* &header, unsigned int seg_size);
	int				calculatePages(long total, int long_seg[255], int last_seg[255]);

public:
	// Constructeur et destructeur
	OggFile();
	~OggFile();

	// La m�thode principale d'acc�s en lecture aux commentaires du fichier Ogg
	int				readOggFile(const char *fileName);

	// Accesseurs
	long int		getFileSize()		{ return tailleFichier; }
	char			*getVendor()		{ return vendor_string; }
	unsigned int	getSerialNumber()	{ return page_serial_number; }
	signed int		getNominalBitrate()	{ return bitrate_nominal; }
	unsigned int	getChannels()		{ return audio_channels; }
	unsigned int	getVorbisVersion()	{ return vorbis_version; }
	unsigned int	getSampleRate()		{ return audio_sample_rate; }
	unsigned int	getNbComments()		{ return user_comment_list_length; }
	char			*getComment(unsigned int i)	{ return comment[i]; }

	// Mutateurs


};

#endif // OGGFILE_H

//=============================================================================
// Fin du fichier OggFile.h
//=============================================================================
